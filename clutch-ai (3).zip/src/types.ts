export type Priority = 'high' | 'medium' | 'low';
export type TaskStatus = 'pending' | 'in_progress' | 'completed';

export interface SubTask {
  id: string;
  title: string;
  completed: boolean;
  durationMinutes?: number;
}

export interface AISurvivalPlan {
  steps: {
    id: string;
    title: string;
    duration: number; // in minutes
    description: string;
    completed?: boolean;
  }[];
  focusTips: string[];
  estimatedTotalTime: number; // in minutes
  procrastinationBuster: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  deadline: string; // ISO String (e.g., "2026-06-28T18:00")
  priority: Priority;
  status: TaskStatus;
  subtasks: SubTask[];
  aiPlan?: AISurvivalPlan;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  urgencyScore: number; // 0 to 100
  createdAt: string;
  isLockedForAssistance?: boolean;
  estimatedDuration?: number; // in minutes
  postponedCount?: number;
}

export interface UserBehavior {
  preferredWorkingHours?: string; // e.g. "09:00-17:00"
  frequentlyPostponedTasks?: string[];
  averageCompletionTimes?: { [category: string]: number };
  lastActivityTime?: string;
  productivityPatterns?: {
    peakFocusHour?: number;
    completedTasksCount?: number;
    totalFocusMinutes?: number;
  };
  commonDelayReasons?: { [reason: string]: number };
  dailyReflections?: {
    id: string;
    date: string;
    tasksCompleted: number;
    tasksPostponed: number;
    productivityScore: number;
    habitProgress: number;
    timeSpentWorking: number;
    biggestAchievement: string;
    suggestedImprovement: string;
  }[];
  weeklyReviews?: {
    id: string;
    date: string;
    productivityTrends: { day: string; score: number }[];
    mostProductiveDays: string[];
    leastProductiveDays: string[];
    habitConsistency: number;
    goalProgress: number;
    frequentlyDelayedTasks: string[];
    recommendations: string[];
  }[];
}

export interface Goal {
  id: string;
  title: string;
  targetDate: string;
  completed: boolean;
  category: string;
  tasksCount: number;
  completedTasksCount: number;
}

export interface Habit {
  id: string;
  title: string;
  frequency: 'daily' | 'weekly';
  streak: number;
  lastCompleted?: string; // "YYYY-MM-DD"
  history: { [date: string]: boolean };
  createdAt: string;
}

export interface CalendarEvent {
  id: string;
  title: string;
  startTime: string; // ISO date-time
  endTime: string; // ISO date-time
  associatedTaskId?: string;
  color?: string;
}

export interface ProductivitySummary {
  completionRate: number;
  highPriorityCount: number;
  completedCount: number;
  pendingCount: number;
  currentStreak: number;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  suggestedAction?: {
    type: 'create_task' | 'create_plan' | 'prioritize' | 'block_time';
    payload: any;
  };
}
