import React, { useState, useRef, useEffect } from 'react';
import { Send, Mic, MicOff, Volume2, VolumeX, Sparkles, User, AlertCircle, Play, Check } from 'lucide-react';
import { ChatMessage, Task, Habit, Goal, UserBehavior } from '../types';

interface CompanionChatProps {
  tasks: Task[];
  habits?: Habit[];
  goals?: Goal[];
  userBehavior?: UserBehavior;
  onExecuteSuggestedAction: (actionType: string, payload: any) => void;
  triggerOpenWithTask?: string | null; // task title to auto-prompt planning for
}

export default function CompanionChat({
  tasks,
  habits = [],
  goals = [],
  userBehavior,
  onExecuteSuggestedAction,
  triggerOpenWithTask,
}: CompanionChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: "Hey! I'm your Last-Minute Companion. Whether you're drowning in work or procrastinating a deadline, talk or type to me. Tell me what's on your mind, or try saying 'I need to write an essay by 9 PM tonight'.",
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [speechEnabled, setSpeechEnabled] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  // Initialize Speech Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsListening(true);
        setError(null);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setInput(transcript);
        }
      };

      rec.onerror = (e: any) => {
        console.log('Speech recognition debug:', e);
        setIsListening(false);
        setError('Voice capture is currently unavailable. Please verify browser permissions.');
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  // Handle auto prompt triggers
  useEffect(() => {
    if (triggerOpenWithTask) {
      sendMessage(`Help me make an AI Survival Plan for "${triggerOpenWithTask}"`);
    }
  }, [triggerOpenWithTask]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const toggleListening = () => {
    if (!recognitionRef.current) {
      setError('Speech recognition is not supported in this browser. Please use Chrome/Safari/Edge.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.log('Speech start debug:', err);
      }
    }
  };

  const speakText = (text: string) => {
    if (!speechEnabled) return;
    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.05;
      utterance.pitch = 1.0;
      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.log('Text to speech debug:', err);
    }
  };

  const sendMessage = async (textToSend?: string) => {
    const messageText = (textToSend || input).trim();
    if (!messageText) return;

    if (!textToSend) {
      setInput('');
    }

    setError(null);
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      sender: 'user',
      text: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: messageText,
          history: messages.map(m => ({ role: m.sender === 'user' ? 'user' : 'model', parts: [{ text: m.text }] })),
          tasks,
          habits,
          goals,
          userBehavior,
          currentLocalTime: new Date().toISOString(),
        }),
      });

      if (!res.ok) {
        throw new Error('AI Coach is taking a coffee break. Let\'s try again.');
      }

      const data = await res.json();
      const aiResponseText = data.reply || "I'm with you, let's keep moving!";

      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiResponseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        suggestedAction: data.suggestedAction ? {
          type: data.suggestedAction.type,
          payload: data.suggestedAction.payload,
        } : undefined,
      };

      setMessages(prev => [...prev, aiMsg]);
      speakText(aiResponseText);
    } catch (err: any) {
      console.log('AI Coach connection debug:', err);
      // Fallback response
      const fallbackReplies = [
        "That sounds important! Let's get it added as a high-priority survival task so you can plan it.",
        "Procrastination can trigger mental blocks. Let's write down a single action you can complete in 2 minutes.",
        "Got it! Let's schedule that event on your calendar to reserve that block of time.",
        "I'm here! Let's build a timeline of steps to cross the finish line before your deadline."
      ];
      const randomReply = fallbackReplies[Math.floor(Math.random() * fallbackReplies.length)];

      const aiMsg: ChatMessage = {
        id: `ai-err-${Date.now()}`,
        sender: 'ai',
        text: randomReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleActionExecution = (msgId: string, actionType: string, payload: any) => {
    // Execute action
    onExecuteSuggestedAction(actionType, payload);

    // Filter out or mark action as executed in UI
    setMessages(prev =>
      prev.map(m => {
        if (m.id === msgId) {
          return { ...m, suggestedAction: undefined };
        }
        return m;
      })
    );
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm flex flex-col h-[520px]">
      {/* Header */}
      <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50 rounded-t-2xl">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-full bg-violet-600 flex items-center justify-center text-white">
            <Sparkles className="w-4 h-4 fill-violet-100" />
          </div>
          <div>
            <h3 className="font-semibold text-slate-800 text-sm">Life Saver AI Coach</h3>
            <span className="text-[10px] text-emerald-500 font-medium flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
              Online Companion
            </span>
          </div>
        </div>

        <button
          onClick={() => {
            const next = !speechEnabled;
            setSpeechEnabled(next);
            if (!next) window.speechSynthesis.cancel();
          }}
          className={`p-2 rounded-lg border text-xs font-medium flex items-center gap-1 transition ${
            speechEnabled
              ? 'bg-violet-50 text-violet-600 border-violet-100'
              : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
          }`}
          title={speechEnabled ? "Mute audio response" : "Enable voice response"}
        >
          {speechEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          <span>{speechEnabled ? 'Voice On' : 'Silent'}</span>
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((m) => (
          <div key={m.id} className={`flex gap-2.5 max-w-[85%] ${m.sender === 'user' ? 'ml-auto flex-row-reverse' : 'mr-auto'}`}>
            <div className={`w-7 h-7 rounded-full shrink-0 flex items-center justify-center text-xs ${
              m.sender === 'user' ? 'bg-indigo-100 text-indigo-700' : 'bg-violet-100 text-violet-700'
            }`}>
              {m.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Sparkles className="w-3.5 h-3.5" />}
            </div>
            <div className="space-y-2">
              <div className={`p-3.5 rounded-2xl text-sm leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-indigo-600 text-white rounded-tr-none'
                  : 'bg-slate-50 text-slate-700 rounded-tl-none border border-slate-100'
              }`}>
                <p className="whitespace-pre-wrap">{m.text}</p>
                <span className={`text-[9px] block text-right mt-1.5 ${m.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {m.timestamp}
                </span>
              </div>

              {/* Proposed Suggested Actions */}
              {m.suggestedAction && (
                <div className="bg-amber-50/50 border border-amber-200 rounded-xl p-3 space-y-2 text-xs">
                  <div className="flex items-center gap-1.5 text-amber-700 font-semibold uppercase tracking-wider text-[10px]">
                    <AlertCircle className="w-3.5 h-3.5" />
                    Coach Proposal
                  </div>
                  <p className="text-slate-700 font-medium">
                    {m.suggestedAction.type === 'create_task' && `Create urgent task: "${m.suggestedAction.payload?.title}"`}
                    {m.suggestedAction.type === 'create_plan' && `Generate AI Survival Plan`}
                    {m.suggestedAction.type === 'prioritize' && `Sort and prioritize pending tasks`}
                    {m.suggestedAction.type === 'block_time' && `Block calendar hours for concentration`}
                  </p>
                  <button
                    onClick={() => handleActionExecution(m.id, m.suggestedAction!.type, m.suggestedAction!.payload)}
                    className="w-full py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-medium flex items-center justify-center gap-1 transition"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Approve & Apply Action
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-2.5 max-w-[80%] mr-auto items-center text-slate-400 text-xs">
            <div className="w-7 h-7 rounded-full bg-violet-50 flex items-center justify-center animate-pulse">
              <Sparkles className="w-3.5 h-3.5 text-violet-400 animate-spin" />
            </div>
            <span>Coach is analyzing intent...</span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Voice feedback / Error */}
      {error && (
        <div className="px-4 py-2 bg-rose-50 border-t border-rose-100 text-[11px] text-rose-600 flex items-center gap-1.5">
          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Input controls */}
      <div className="p-3 border-t border-slate-100 bg-slate-50/50 rounded-b-2xl">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            sendMessage();
          }}
          className="flex items-center gap-2"
        >
          <button
            type="button"
            onClick={toggleListening}
            className={`p-2.5 rounded-xl border transition ${
              isListening
                ? 'bg-rose-100 text-rose-600 border-rose-200 animate-pulse'
                : 'bg-white hover:bg-slate-50 text-slate-500 border-slate-200'
            }`}
            title={isListening ? "Stop listening" : "Speak with Coach"}
          >
            {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={isListening ? "Listening... Speak now..." : "Ask your coach to plan, prioritize, or create a task..."}
            className="flex-1 bg-white border border-slate-200 rounded-xl px-3.5 py-2 text-sm focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500"
          />

          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 bg-violet-600 hover:bg-violet-700 disabled:bg-slate-200 text-white disabled:text-slate-400 rounded-xl transition"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
