import React, { useState } from 'react';
import { Sparkles, AlertTriangle, Lightbulb, ArrowRight, Zap, RefreshCw, BarChart2, ShieldCheck, Heart, User, Clock, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Task, Habit, Goal, UserBehavior } from '../types';

interface RecommendationCardProps {
  tasks: Task[];
  habits: Habit[];
  goals: Goal[];
  onFocusTaskSelect: (task: Task) => void;
  onGeneratePlan: (task: Task) => void;
  refreshTrigger: number;
  userBehavior?: UserBehavior;
}

interface AIRecommendation {
  focusTask: {
    taskId: string | null;
    reason: string;
    delayConsequence?: string;
    estimatedTime?: number;
    bestTimeToStart?: string;
    confidenceScore?: number;
    decisionTimeline?: string[];
  };
  warnings: {
    type: string;
    message: string;
    action: string;
  }[];
  advice: string;
  proactiveQuote: string;
  dailyBriefing?: {
    summary: string;
    totalWorkHours: number;
    habitsAtRisk: string[];
    recommendedFirstStep: string;
  };
  productivityHealth?: {
    burnoutRisk: number;
    focusLevel: number;
    workloadScore: number;
    consistencyScore: number;
    stressIndicator: number;
    explanation: string;
  };
}

export default function RecommendationCard({
  tasks,
  habits,
  goals,
  onFocusTaskSelect,
  onGeneratePlan,
  refreshTrigger,
  userBehavior,
}: RecommendationCardProps) {
  const [loading, setLoading] = useState(false);
  const [rec, setRec] = useState<AIRecommendation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'action' | 'health' | 'briefing'>('action');

  const fetchRecommendations = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/gemini/recommendations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks,
          habits,
          goals,
          userBehavior,
          currentLocalTime: new Date().toISOString(),
        }),
      });

      if (!res.ok) {
        throw new Error('Could not retrieve AI recommendations. Check if Gemini API key is configured.');
      }

      const data = await res.json();
      setRec(data);
    } catch (err: any) {
      console.error(err);
      // Fallback elegant recommendation logic when API key is missing/offline
      generateFallbackRecommendations();
    } finally {
      setLoading(false);
    }
  };

  const generateFallbackRecommendations = () => {
    // Elegant client-side rule-based fallback
    const pendingTasks = tasks.filter(t => t.status !== 'completed');
    
    // Sort tasks by remaining time
    const sortedTasks = [...pendingTasks].sort((a, b) => {
      const timeA = new Date(a.deadline).getTime() - Date.now();
      const timeB = new Date(b.deadline).getTime() - Date.now();
      return timeA - timeB;
    });

    const primaryTask = sortedTasks[0] || null;
    const warnings = [];

    if (primaryTask) {
      const hoursLeft = (new Date(primaryTask.deadline).getTime() - Date.now()) / (1000 * 60 * 60);
      if (hoursLeft < 0) {
        warnings.push({
          type: 'overdue',
          message: `"${primaryTask.title}" has passed its deadline! Let's complete it now.`,
          action: 'Select this task & generate a post-deadline action plan'
        });
      } else if (hoursLeft < 4) {
        warnings.push({
          type: 'deadline_critical',
          message: `CRITICAL: "${primaryTask.title}" is due in ${Math.round(hoursLeft * 10) / 10} hours!`,
          action: 'Generate an AI Survival Plan immediately'
        });
      }
    }

    // Checking decaying habits
    const riskyHabit = habits.find(h => h.streak > 0 && h.lastCompleted !== new Date().toISOString().split('T')[0]);
    if (riskyHabit) {
      warnings.push({
        type: 'habit_risk',
        message: `Your ${riskyHabit.streak}-day streak for "${riskyHabit.title}" is in danger of breaking today!`,
        action: 'Spend 5 minutes to complete this habit right now'
      });
    }

    if (pendingTasks.length > 5) {
      warnings.push({
        type: 'overloaded',
        message: `You currently have ${pendingTasks.length} pending tasks. Task overload causes paralysis.`,
        action: 'Use the AI Prioritizer to sort your day'
      });
    }

    // Intelligent estimates for fallback health
    const totalEstTime = pendingTasks.reduce((sum, t) => sum + (t.estimatedDuration || 45), 0);
    const burnoutRiskVal = Math.min(100, Math.round((pendingTasks.length * 12) + (totalEstTime / 10)));
    const focusLevelVal = habits.length > 0 ? Math.min(100, Math.round((habits.filter(h => h.lastCompleted === new Date().toISOString().split('T')[0]).length / habits.length) * 100)) : 50;

    setRec({
      focusTask: {
        taskId: primaryTask?.id || null,
        reason: primaryTask 
          ? `This is due soonest (${new Date(primaryTask.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}). Focus on this single objective first to clear your mental bandwidth.`
          : 'No urgent tasks pending! Use this quiet time to establish a new habit or review your long-term goals.',
        delayConsequence: primaryTask ? `Delaying this task will compress your schedule, increase your Burnout Risk to ${burnoutRiskVal + 10}%, and put your milestones in immediate critical danger.` : undefined,
        estimatedTime: primaryTask ? (primaryTask.estimatedDuration || 45) : undefined,
        bestTimeToStart: primaryTask ? new Date(Math.max(Date.now() + 15 * 60 * 1000, new Date(primaryTask.deadline).getTime() - 2 * 3600 * 1000)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : undefined,
        confidenceScore: 92,
        decisionTimeline: [
          'Scanned task database for non-completed entries',
          'Calculated absolute proximity to current time',
          'Filtered for maximum threat score',
          'Weighed user work preferences'
        ]
      },
      warnings: warnings.length > 0 ? warnings : [
        {
          type: 'all_clear',
          message: 'No immediate high-urgency threats detected. Smooth sailing!',
          action: 'Break down an upcoming project to stay ahead.'
        }
      ],
      advice: 'To maximize focus, close all secondary web pages, enable your phone\'s Do Not Disturb mode, and dedicate 20 uninterrupted minutes to your focus task. Beating procrastination starts with starting.',
      proactiveQuote: '"Procrastination is the art of keeping up with yesterday." Let\'s take a 2-minute action step right now to tip the scales in your favor.',
      dailyBriefing: {
        summary: `You have ${pendingTasks.length} tasks scheduled today. Total focus time estimated at ${(totalEstTime / 60).toFixed(1)} hours.`,
        totalWorkHours: Math.round(totalEstTime / 60),
        habitsAtRisk: habits.filter(h => h.lastCompleted !== new Date().toISOString().split('T')[0]).map(h => h.title),
        recommendedFirstStep: primaryTask ? `Spend 5 minutes drafting the structure for "${primaryTask.title}".` : "Review your habits list and check off any completed loops."
      },
      productivityHealth: {
        burnoutRisk: burnoutRiskVal,
        focusLevel: focusLevelVal,
        workloadScore: Math.min(100, pendingTasks.length * 15),
        consistencyScore: habits.length > 0 ? Math.min(100, Math.round((habits.reduce((sum, h) => sum + h.streak, 0) / habits.length) * 20)) : 60,
        stressIndicator: primaryTask ? Math.min(100, Math.round(100 - (new Date(primaryTask.deadline).getTime() - Date.now()) / (3600 * 1000 * 4))) : 15,
        explanation: 'Overall mental load is stable. Prioritize your top focus task to prevent a late afternoon workload spike.'
      }
    });
  };

  React.useEffect(() => {
    fetchRecommendations();
  }, [tasks.length, habits.length, goals.length, refreshTrigger]);

  const [showTimeline, setShowTimeline] = useState(false);
  const matchingFocusTask = tasks.find(t => t.id === rec?.focusTask?.taskId);

  return (
    <div id="ai-rec-panel" className="space-y-4">
      {/* Dynamic Sub-Tab Selector to reduce congestion */}
      <div className="bg-slate-50 p-1.5 rounded-2xl border border-slate-200/50 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-2 pl-2">
          <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
          <span className="font-bold text-[10px] text-slate-500 uppercase tracking-wider">AI Copilot Hub</span>
        </div>
        <div className="flex bg-slate-200/50 p-0.5 rounded-xl border border-slate-200/40 shadow-inner gap-1 w-full sm:w-auto">
          <button
            onClick={() => setActiveSubTab('action')}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
              activeSubTab === 'action'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-200'
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${activeSubTab === 'action' ? 'text-white fill-white/25' : 'text-slate-400'}`} />
            <span>Next Action</span>
          </button>
          <button
            onClick={() => setActiveSubTab('health')}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
              activeSubTab === 'health'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-200'
            }`}
          >
            <BarChart2 className={`w-3.5 h-3.5 ${activeSubTab === 'health' ? 'text-white' : 'text-slate-400'}`} />
            <span>Health Stats</span>
          </button>
          <button
            onClick={() => setActiveSubTab('briefing')}
            className={`flex-1 sm:flex-initial px-3.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
              activeSubTab === 'briefing'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-200'
            }`}
          >
            <ShieldCheck className={`w-3.5 h-3.5 ${activeSubTab === 'briefing' ? 'text-white' : 'text-slate-400'}`} />
            <span>AI Briefing</span>
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeSubTab}
          initial={{ opacity: 0, y: 4 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -4 }}
          transition={{ duration: 0.15 }}
          className="space-y-4"
        >
          {activeSubTab === 'briefing' && rec?.dailyBriefing && (
            <div className="bg-gradient-to-r from-violet-600 to-indigo-700 text-white rounded-2xl shadow-md p-6 relative overflow-hidden">
              {/* Decorative radial blur */}
              <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/10 rounded-full blur-2xl pointer-events-none" />
              <div className="flex items-center gap-2.5 mb-3">
                <ShieldCheck className="w-5 h-5 text-emerald-300" />
                <span className="text-[11px] font-bold tracking-wider uppercase bg-white/20 px-2.5 py-1 rounded-full text-indigo-50">
                  Personalized Daily AI Briefing
                </span>
              </div>
              <h3 className="font-semibold text-lg leading-snug md:text-xl font-sans mb-2">
                {rec.dailyBriefing.summary}
              </h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4 pt-4 border-t border-white/15">
                <div>
                  <span className="block text-[10px] text-indigo-200 font-bold uppercase tracking-wider">Required Focus</span>
                  <p className="text-sm font-semibold mt-0.5 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-emerald-300 shrink-0" />
                    {rec.dailyBriefing.totalWorkHours} hours today
                  </p>
                </div>
                <div>
                  <span className="block text-[10px] text-indigo-200 font-bold uppercase tracking-wider">Habits At Risk</span>
                  <p className="text-sm font-semibold mt-0.5 flex items-center gap-1.5">
                    <Heart className="w-4 h-4 text-rose-300 shrink-0" />
                    {rec.dailyBriefing.habitsAtRisk.length > 0 ? (
                      <span className="text-rose-200 truncate">{rec.dailyBriefing.habitsAtRisk.join(', ')}</span>
                    ) : (
                      <span className="text-emerald-300">All habits locked!</span>
                    )}
                  </p>
                </div>
                <div className="col-span-2 md:col-span-1">
                  <span className="block text-[10px] text-indigo-200 font-bold uppercase tracking-wider">Starting Task</span>
                  <p className="text-xs font-semibold mt-0.5 text-amber-200 italic line-clamp-1">
                    {rec.dailyBriefing.recommendedFirstStep}
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'health' && rec?.productivityHealth && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-rose-500 fill-rose-500 animate-pulse" />
                  <h3 className="font-semibold text-slate-800 text-sm">Productivity Health Center</h3>
                </div>
                <span className="text-[10px] bg-slate-50 border border-slate-100 px-2 py-0.5 rounded text-slate-500 font-medium">
                  Live Diagnostics
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
                {[
                  { label: 'Burnout Risk', value: rec.productivityHealth.burnoutRisk, color: 'bg-rose-500', bg: 'bg-rose-50' },
                  { label: 'Focus Level', value: rec.productivityHealth.focusLevel, color: 'bg-indigo-500', bg: 'bg-indigo-50' },
                  { label: 'Workload Score', value: rec.productivityHealth.workloadScore, color: 'bg-amber-500', bg: 'bg-amber-50' },
                  { label: 'Consistency', value: rec.productivityHealth.consistencyScore, color: 'bg-emerald-500', bg: 'bg-emerald-50' },
                  { label: 'Stress Index', value: rec.productivityHealth.stressIndicator, color: 'bg-violet-500', bg: 'bg-violet-50' },
                ].map((item, idx) => (
                  <div key={idx} className={`${item.bg} border border-slate-100/40 rounded-xl p-3 flex flex-col justify-between`}>
                    <span className="text-[10px] text-slate-500 font-bold leading-tight block">{item.label}</span>
                    <div className="mt-2.5">
                      <div className="flex justify-between text-xs font-bold text-slate-800 mb-1">
                        <span>{item.value}%</span>
                      </div>
                      <div className="w-full bg-slate-200/50 h-1 rounded-full overflow-hidden">
                        <div className={`h-full ${item.color}`} style={{ width: `${item.value}%` }} />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-slate-500 bg-slate-50/50 rounded-lg p-2.5 border border-slate-100 italic leading-normal">
                <strong>Diagnostic Summary:</strong> {rec.productivityHealth.explanation}
              </p>
            </div>
          )}

          {activeSubTab === 'action' && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 overflow-hidden relative">
                <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full blur-3xl opacity-60 -mr-6 -mt-6 pointer-events-none" />

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                      <Sparkles className="w-5 h-5 animate-pulse" />
                    </div>
                    <div>
                      <h2 className="font-semibold text-slate-800 text-base">AI Next Best Action</h2>
                      <p className="text-[10px] text-slate-400">Proactive target tracking & schedule optimization</p>
                    </div>
                  </div>
                  <button
                    onClick={fetchRecommendations}
                    disabled={loading}
                    className="p-1.5 hover:bg-slate-50 rounded-lg text-slate-400 hover:text-slate-600 transition"
                    title="Refresh recommendations"
                  >
                    <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {loading ? (
                  <div className="py-12 flex flex-col items-center justify-center text-slate-400 gap-2">
                    <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
                    <span className="text-xs">Companion is auditing lists and training metrics...</span>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {/* Proactive Quote */}
                    {rec?.proactiveQuote && (
                      <div className="bg-slate-50 rounded-xl p-3 border-l-4 border-indigo-400 text-slate-600 italic text-xs">
                        {rec.proactiveQuote}
                      </div>
                    )}

                    {/* Focus Task details */}
                    {rec?.focusTask && (
                      <div className="bg-gradient-to-r from-indigo-50/40 to-violet-50/40 rounded-xl p-4 border border-indigo-100/40 space-y-3.5">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5 text-indigo-600 font-bold text-[10px] uppercase tracking-wider">
                            <Zap className="w-3.5 h-3.5 fill-indigo-100" />
                            Focus Objective
                          </div>
                          {rec.focusTask.confidenceScore && (
                            <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded text-[9px] font-bold border border-emerald-100 flex items-center gap-1">
                              Confidence: {rec.focusTask.confidenceScore}%
                            </span>
                          )}
                        </div>

                        {matchingFocusTask ? (
                          <div className="space-y-3">
                            <div>
                              <h3 className="font-semibold text-slate-800 text-base">{matchingFocusTask.title}</h3>
                              
                              {/* Detailed explanatory metrics */}
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                                <div className="bg-white/80 border border-slate-100 rounded-lg p-2">
                                  <span className="block text-[9px] text-slate-400 font-bold uppercase">Why Selected</span>
                                  <p className="text-[11px] text-slate-600 mt-0.5 leading-normal">{rec.focusTask.reason}</p>
                                </div>
                                {rec.focusTask.delayConsequence && (
                                  <div className="bg-white/80 border border-slate-100 rounded-lg p-2">
                                    <span className="block text-[9px] text-rose-500 font-bold uppercase">If Delayed?</span>
                                    <p className="text-[11px] text-rose-700 mt-0.5 leading-normal">{rec.focusTask.delayConsequence}</p>
                                  </div>
                                )}
                              </div>

                              {/* Estimated start / duration */}
                              <div className="flex gap-4 mt-3 text-[11px] text-slate-500 font-medium">
                                {rec.focusTask.estimatedTime && (
                                  <div className="flex items-center gap-1">
                                    <Clock className="w-3.5 h-3.5 text-indigo-500" />
                                    <span>Duration: {rec.focusTask.estimatedTime} min</span>
                                  </div>
                                )}
                                {rec.focusTask.bestTimeToStart && (
                                  <div className="flex items-center gap-1">
                                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                                    <span>Best Start: {rec.focusTask.bestTimeToStart}</span>
                                  </div>
                                )}
                              </div>
                            </div>

                            {/* Expandable AI Decision Timeline */}
                            {rec.focusTask.decisionTimeline && (
                              <div className="border-t border-indigo-100/30 pt-3">
                                <button
                                  onClick={() => setShowTimeline(!showTimeline)}
                                  className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1"
                                >
                                  {showTimeline ? 'Hide reasoning process' : 'Show AI Decision Timeline (4 layers)'}
                                </button>
                                
                                <AnimatePresence>
                                  {showTimeline && (
                                    <motion.div
                                      initial={{ opacity: 0, height: 0 }}
                                      animate={{ opacity: 1, height: 'auto' }}
                                      exit={{ opacity: 0, height: 0 }}
                                      className="mt-2 pl-2 border-l border-indigo-200 space-y-2 py-1 overflow-hidden"
                                    >
                                      {rec.focusTask.decisionTimeline.map((step, idx) => (
                                        <div key={idx} className="flex items-start gap-2 text-[10px] text-slate-500">
                                          <span className="w-4 h-4 rounded-full bg-indigo-50 border border-indigo-100 text-[9px] font-bold text-indigo-600 flex items-center justify-center shrink-0">
                                            {idx + 1}
                                          </span>
                                          <span className="pt-0.5 leading-tight">{step}</span>
                                        </div>
                                      ))}
                                    </motion.div>
                                  )}
                                </AnimatePresence>
                              </div>
                            )}

                            <div className="flex gap-2 pt-2 flex-wrap">
                              <button
                                onClick={() => onFocusTaskSelect(matchingFocusTask)}
                                className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition"
                              >
                                Focus on Task
                                <ArrowRight className="w-3 h-3" />
                              </button>
                              {!matchingFocusTask.aiPlan && (
                                <button
                                  onClick={() => onGeneratePlan(matchingFocusTask)}
                                  className="px-3.5 py-1.5 bg-white hover:bg-slate-50 text-indigo-600 border border-indigo-200 rounded-xl text-xs font-semibold transition"
                                >
                                  Generate AI Survival Plan
                                </button>
                              )}
                            </div>
                          </div>
                        ) : (
                          <p className="text-xs text-slate-600">{rec.focusTask.reason}</p>
                        )}
                      </div>
                    )}

                    {/* Action Alerts / Warnings */}
                    {rec && rec.warnings.length > 0 && (
                      <div className="space-y-2">
                        <div className="text-[10px] font-bold text-slate-400 tracking-wider uppercase">Active Threat Alerts</div>
                        {rec.warnings.map((warning, i) => (
                          <div
                            key={i}
                            className={`flex gap-3 p-3 rounded-xl border text-xs ${
                              warning.type.includes('critical') || warning.type.includes('overdue')
                                ? 'bg-rose-50/60 border-rose-100 text-rose-800'
                                : warning.type === 'all_clear'
                                ? 'bg-emerald-50/40 border-emerald-100 text-emerald-800'
                                : 'bg-amber-50/60 border-amber-100 text-amber-800'
                            }`}
                          >
                            <div className="shrink-0 mt-0.5">
                              <AlertTriangle className={`w-4 h-4 ${warning.type.includes('critical') ? 'text-rose-600' : 'text-amber-500'}`} />
                            </div>
                            <div>
                              <p className="font-semibold text-slate-800 leading-snug">{warning.message}</p>
                              <p className="text-[10px] opacity-85 mt-1 italic">Suggested: {warning.action}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* General Advice */}
                    {rec?.advice && (
                      <div className="flex gap-2 items-start bg-slate-50/50 rounded-xl p-3 border border-slate-100 text-xs text-slate-500 leading-normal">
                        <Lightbulb className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                        <span>{rec.advice}</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
