import React, { useState, useEffect, useRef } from 'react';
import {
  Plus,
  Clock,
  Calendar as CalendarIcon,
  CheckCircle,
  Circle,
  Flame,
  Award,
  Sparkles,
  Zap,
  Activity,
  AlertTriangle,
  Play,
  RotateCcw,
  Check,
  Volume2,
  VolumeX,
  Mic,
  MicOff,
  Trash2,
  ChevronRight,
  ShieldAlert,
  SlidersHorizontal,
  Lightbulb,
  CornerDownRight,
  ArrowRight,
  Target,
  Brain,
  Bell,
  Edit
} from 'lucide-react';
import { Task, SubTask, Habit, Goal, CalendarEvent } from './types';
import { motion, AnimatePresence } from 'motion/react';
import RecommendationCard from './components/RecommendationCard';
import CompanionChat from './components/CompanionChat';

export default function App() {
  // --- Persistent State ---
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('saver_tasks');
    if (saved) return JSON.parse(saved);
    // Starter high-urgency tasks to make the initial experience feel rich & realistic
    const today = new Date();
    const tonightHigh = new Date(today);
    tonightHigh.setHours(21, 0, 0, 0);
    const tomorrowMed = new Date(today);
    tomorrowMed.setDate(tomorrowMed.getDate() + 1);
    tomorrowMed.setHours(14, 0, 0, 0);

    return [
      {
        id: '1',
        title: 'Submit Final Q2 Budget Review',
        description: 'Verify Excel formula inconsistencies on cell H12 and send the sheet directly to executive leadership.',
        deadline: tonightHigh.toISOString().substring(0, 16),
        priority: 'high',
        status: 'pending',
        subtasks: [
          { id: '1-1', title: 'Double check lead calculations', completed: false, durationMinutes: 15 },
          { id: '1-2', title: 'Export PDF to Leadership sharepoint', completed: false, durationMinutes: 10 },
        ],
        category: 'Work',
        difficulty: 'hard',
        urgencyScore: 92,
        createdAt: new Date().toISOString()
      },
      {
        id: '2',
        title: 'Renew Renters Insurance Policy',
        description: 'Policy expires in 36 hours. Compare previous rate with Geico premium option.',
        deadline: tomorrowMed.toISOString().substring(0, 16),
        priority: 'medium',
        status: 'pending',
        subtasks: [
          { id: '2-1', title: 'Locate PDF policy document', completed: true, durationMinutes: 5 },
          { id: '2-2', title: 'Make payment on portal', completed: false, durationMinutes: 10 },
        ],
        category: 'Personal',
        difficulty: 'easy',
        urgencyScore: 68,
        createdAt: new Date().toISOString()
      }
    ];
  });

  const [habits, setHabits] = useState<Habit[]>(() => {
    const saved = localStorage.getItem('saver_habits');
    if (saved) return JSON.parse(saved);
    return [
      {
        id: 'h1',
        title: 'Deep Work Session (45m)',
        frequency: 'daily',
        streak: 3,
        lastCompleted: new Date(Date.now() - 86400000).toISOString().split('T')[0],
        history: {},
        createdAt: new Date().toISOString()
      },
      {
        id: 'h2',
        title: 'Inbox Zero & Clean Desk',
        frequency: 'daily',
        streak: 0,
        history: {},
        createdAt: new Date().toISOString()
      }
    ];
  });

  const [goals, setGoals] = useState<Goal[]>(() => {
    const saved = localStorage.getItem('saver_goals');
    if (saved) return JSON.parse(saved);
    const target = new Date();
    target.setDate(target.getDate() + 5);
    return [
      {
        id: 'g1',
        title: 'Q2 Performance Report Submission',
        targetDate: target.toISOString().split('T')[0],
        completed: false,
        category: 'Work',
        tasksCount: 2,
        completedTasksCount: 0
      }
    ];
  });

  const [events, setEvents] = useState<CalendarEvent[]>(() => {
    const saved = localStorage.getItem('saver_events');
    if (saved) return JSON.parse(saved);
    // Starter calendar event matching first task
    const today = new Date();
    const startHour = new Date(today);
    startHour.setHours(17, 0, 0, 0);
    const endHour = new Date(today);
    endHour.setHours(18, 0, 0, 0);

    return [
      {
        id: 'e1',
        title: 'Dedicated Q2 Budget Review Slot',
        startTime: startHour.toISOString().substring(0, 16),
        endTime: endHour.toISOString().substring(0, 16),
        associatedTaskId: '1',
        color: 'indigo'
      }
    ];
  });

  // --- UI Interactivity State ---
  const [activeTab, setActiveTab] = useState<'dashboard' | 'calendar' | 'habits' | 'coach'>('dashboard');
  const [selectedTask, setSelectedTask] = useState<Task | null>(tasks[0] || null);
  const [isPrioritizing, setIsPrioritizing] = useState(false);
  const [isPlanning, setIsPlanning] = useState(false);
  const [recRefreshTrigger, setRecRefreshTrigger] = useState(0);
  const [chatTriggerTask, setChatTriggerTask] = useState<string | null>(null);
  const [showSecondaryTasks, setShowSecondaryTasks] = useState(false);
  const [showCompletedTasks, setShowCompletedTasks] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [postponingTaskId, setPostponingTaskId] = useState<string | null>(null);
  const [showImpactSimulator, setShowImpactSimulator] = useState(false);

  // User Behavior patterns learned over time
  const [userBehavior, setUserBehavior] = useState<any>(() => {
    const saved = localStorage.getItem('saver_behavior');
    if (saved) return JSON.parse(saved);
    return {
      preferredWorkingHours: ['09:00', '17:00'],
      frequentlyPostponedTasks: [],
      averageCompletionTimes: {},
      productivityPatterns: {
        peakFocusHour: 10,
        completedTasksCount: 0,
        totalFocusMinutes: 0
      },
      habitConsistency: 100
    };
  });

  // Survival Plan Timer State
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);

  // Task Editing State
  const [isEditingTask, setIsEditingTask] = useState<boolean>(false);
  const [editTaskTitle, setEditTaskTitle] = useState<string>('');
  const [editTaskDesc, setEditTaskDesc] = useState<string>('');
  const [editTaskDeadline, setEditTaskDeadline] = useState<string>('');
  const [editTaskPriority, setEditTaskPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [editTaskCategory, setEditTaskCategory] = useState<string>('Work');
  const [editTaskDifficulty, setEditTaskDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');

  // Automatically load selected task fields into editing states and turn off edit mode when selection changes
  useEffect(() => {
    if (selectedTask) {
      setEditTaskTitle(selectedTask.title);
      setEditTaskDesc(selectedTask.description || '');
      setEditTaskDeadline(selectedTask.deadline);
      setEditTaskPriority(selectedTask.priority);
      setEditTaskCategory(selectedTask.category);
      setEditTaskDifficulty(selectedTask.difficulty);
    }
    setIsEditingTask(false);
  }, [selectedTask?.id]);

  // --- Voice Commands / Assistant States & Refs ---
  const [voiceBriefingEnabled, setVoiceBriefingEnabled] = useState(false);
  const [isListeningForCommands, setIsListeningForCommands] = useState(false);
  const [voiceCommandFeedback, setVoiceCommandFeedback] = useState<string | null>(null);
  const [spokenText, setSpokenText] = useState<string>('');
  const recognitionRef = useRef<any>(null);

  const selectedTaskRef = useRef<Task | null>(null);
  const activeTabRef = useRef<string>('dashboard');
  const voiceBriefingEnabledRef = useRef<boolean>(false);

  useEffect(() => {
    selectedTaskRef.current = selectedTask;
  }, [selectedTask]);

  useEffect(() => {
    activeTabRef.current = activeTab;
  }, [activeTab]);

  useEffect(() => {
    voiceBriefingEnabledRef.current = voiceBriefingEnabled;
  }, [voiceBriefingEnabled]);

  const speakTaskDetails = (task: Task) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    let text = `Let's focus on: ${task.title}. This is a ${task.priority} priority task categorized under ${task.category} with ${task.difficulty} difficulty. `;
    if (task.description) {
      text += `The context is: ${task.description}. `;
    }
    
    if (task.subtasks && task.subtasks.length > 0) {
      const pendingSubtasks = task.subtasks.filter(s => !s.completed);
      if (pendingSubtasks.length > 0) {
        text += `You have ${pendingSubtasks.length} pending subtasks. Let's tackle them starting with: ${pendingSubtasks[0].title}. `;
      } else {
        text += `All your subtasks are completed. Excellent work! `;
      }
    } else {
      text += `This is a complex task. To conquer procrastination, you should break this task down into smaller subtasks. Click the "Auto-Decompose" button, or say 'break task' to let me split it for you! `;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const speakResponse = (text: string) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;
    window.speechSynthesis.speak(utterance);
  };

  const handleVoiceCommand = (commandText: string) => {
    const text = commandText.toLowerCase().trim();
    setVoiceCommandFeedback(`Captured: "${commandText}"`);

    const currentTask = selectedTaskRef.current;

    if (text.includes('tell') || text.includes('about') || text.includes('explain') || text.includes('read') || text.includes('briefing') || text.includes('describe')) {
      if (currentTask) {
        speakTaskDetails(currentTask);
      } else {
        speakResponse("No task is currently selected. Click a task first to hear about it.");
      }
    } else if (text.includes('break') || text.includes('decompose') || text.includes('split') || text.includes('smaller')) {
      if (currentTask) {
        speakResponse(`Decomposing task: ${currentTask.title}`);
        handleAutoDecomposeSubtasks(currentTask);
      } else {
        speakResponse("No task is currently selected to decompose. Click a task first.");
      }
    } else if (text.includes('complete') || text.includes('finish') || text.includes('mark done') || text.includes('mark completed')) {
      if (currentTask) {
        speakResponse(`Marking task ${currentTask.title} as completed.`);
        handleToggleTaskStatus(currentTask.id);
      } else {
        speakResponse("Select a task first to mark it as completed.");
      }
    } else if (text.includes('postpone')) {
      if (currentTask) {
        speakResponse(`Postponing task ${currentTask.title} by one hour.`);
        handlePostponeTask(currentTask.id);
      } else {
        speakResponse("Select a task first to postpone.");
      }
    } else if (text.startsWith('add subtask') || text.startsWith('add step')) {
      if (currentTask) {
        const rawTitle = commandText.replace(/add subtask/i, '').replace(/add step/i, '').trim();
        if (rawTitle) {
          speakResponse(`Adding subtask: ${rawTitle}`);
          handleAddSubtask(currentTask.id, rawTitle);
        } else {
          speakResponse("Please say 'add subtask' followed by the step name.");
        }
      } else {
        speakResponse("Select a task first to add subtasks.");
      }
    } else if (text.includes('show calendar') || text.includes('go to calendar')) {
      speakResponse("Opening calendar tab.");
      setActiveTab('calendar');
    } else if (text.includes('show dashboard') || text.includes('go to dashboard')) {
      speakResponse("Opening dashboard tab.");
      setActiveTab('dashboard');
    } else if (text.includes('show habits') || text.includes('go to habits')) {
      speakResponse("Opening habits tab.");
      setActiveTab('habits');
    } else if (text.includes('show coach') || text.includes('go to coach')) {
      speakResponse("Opening coach tab.");
      setActiveTab('coach');
    } else if (text.includes('silence') || text.includes('stop voice') || text.includes('shut up') || text.includes('mute')) {
      window.speechSynthesis.cancel();
      setVoiceBriefingEnabled(false);
      speakResponse("Voice briefing has been muted.");
    } else if (text.includes('turn on voice') || text.includes('enable voice')) {
      setVoiceBriefingEnabled(true);
      speakResponse("Voice briefing is now active.");
    } else {
      setVoiceCommandFeedback(`Unrecognized command: "${commandText}". Try saying 'tell me about it' or 'break task'.`);
    }
  };

  // Initialize Voice Command Recognition
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';

      rec.onstart = () => {
        setIsListeningForCommands(true);
        setVoiceCommandFeedback('Listening for commands...');
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        if (transcript) {
          setSpokenText(transcript);
          handleVoiceCommand(transcript);
        }
      };

      rec.onerror = (e: any) => {
        console.log('Voice Command error:', e);
        setIsListeningForCommands(false);
        setVoiceCommandFeedback('Error capturing voice. Verify mic permissions.');
      };

      rec.onend = () => {
        setIsListeningForCommands(false);
      };

      recognitionRef.current = rec;
    }
  }, []);

  const handleSelectTask = (task: Task) => {
    setSelectedTask(task);
    if (voiceBriefingEnabledRef.current) {
      speakTaskDetails(task);
    }
  };

  // New Item Creation Modals/Forms State
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [newTaskDeadline, setNewTaskDeadline] = useState('');
  const [newTaskPriority, setNewTaskPriority] = useState<'high' | 'medium' | 'low'>('medium');
  const [newTaskCategory, setNewTaskCategory] = useState('Work');
  const [newTaskDifficulty, setNewTaskDifficulty] = useState<'easy' | 'medium' | 'hard'>('medium');

  const [newHabitTitle, setNewHabitTitle] = useState('');
  const [newGoalTitle, setNewGoalTitle] = useState('');
  const [newGoalDate, setNewGoalDate] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState('Work');

  const [newEventTitle, setNewEventTitle] = useState('');
  const [newEventStart, setNewEventStart] = useState('');
  const [newEventEnd, setNewEventEnd] = useState('');
  const [newEventTaskId, setNewEventTaskId] = useState('');

  // --- Dynamic Smart Notifications ---
  const notifications = React.useMemo(() => {
    const list = [];
    
    // Inactivity / Fatigue advisory
    list.push({
      id: 'fatigue',
      title: 'Cognitive Reset Advisor',
      text: "🧘 Fatigue Warning: You've been active for 40 minutes in dashboard. Stand up and take a 5-minute break.",
      type: 'warning'
    });

    // Peak hours
    const currentHour = new Date().getHours();
    const peakHour = userBehavior?.productivityPatterns?.peakFocusHour || 10;
    const formattedPeakHour = peakHour > 12 ? `${peakHour - 12}:00 PM` : `${peakHour}:00 AM`;
    if (currentHour === peakHour) {
      list.push({
        id: 'peak',
        title: 'Peak Focus Period',
        text: `⚡ Peak hour active! Work velocity is boosted. Best time for high-value backlog items.`,
        type: 'success'
      });
    }

    // Workload relief
    const pendingTasks = tasks.filter(t => t.status !== 'completed');
    if (pendingTasks.length > 0) {
      list.push({
        id: 'relief',
        title: 'Workload Optimizer',
        text: `💡 Completing your focus task now reduces tomorrow's remaining workload by 35%.`,
        type: 'info'
      });
    }

    // Streak / Habit
    const pendingHabits = habits.filter(h => {
      const todayStr = new Date().toISOString().split('T')[0];
      return h.lastCompleted !== todayStr;
    });
    if (pendingHabits.length === 1) {
      list.push({
        id: 'streak',
        title: 'Streak At Risk',
        text: `🔥 Only one habit ("${pendingHabits[0].title}") remains to lock in your daily habit loop consistency!`,
        type: 'alert'
      });
    }

    return list;
  }, [tasks, habits, userBehavior]);

  // --- Effects ---
  useEffect(() => {
    localStorage.setItem('saver_tasks', JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem('saver_behavior', JSON.stringify(userBehavior));
  }, [userBehavior]);

  useEffect(() => {
    localStorage.setItem('saver_habits', JSON.stringify(habits));
  }, [habits]);

  useEffect(() => {
    localStorage.setItem('saver_goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem('saver_events', JSON.stringify(events));
  }, [events]);

  // Handle active survival plan timer countdown
  useEffect(() => {
    let interval: any = null;
    if (timerRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerRunning) {
      setTimerRunning(false);
      // Optional sound notify alert
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = audioCtx.createOscillator();
        const gainNode = audioCtx.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(600, audioCtx.currentTime);
        gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
        oscillator.start();
        oscillator.stop(audioCtx.currentTime + 0.8);
      } catch (err) {
        console.log('Audio notification bypassed');
      }
    }
    return () => clearInterval(interval);
  }, [timerRunning, timeLeft]);

  // Reset active step countdown timer when step changes
  const selectSurvivalStep = (index: number) => {
    if (!selectedTask || !selectedTask.aiPlan) return;
    setCurrentStepIndex(index);
    setTimeLeft(selectedTask.aiPlan.steps[index].duration * 60);
    setTimerRunning(false);
  };

  // Start/pause active survival countdown timer
  const toggleTimer = () => {
    if (timeLeft === 0 && selectedTask?.aiPlan) {
      // Initialize if time expired or uninitialized
      setTimeLeft(selectedTask.aiPlan.steps[currentStepIndex].duration * 60);
    }
    setTimerRunning(!timerRunning);
  };

  // --- Task Operations ---
  const handleCreateTask = (data: Partial<Task>) => {
    const t: Task = {
      id: `task-${Date.now()}`,
      title: data.title || 'Untitled Task',
      description: data.description || '',
      deadline: data.deadline || new Date(Date.now() + 86400000).toISOString().substring(0, 16),
      priority: data.priority || 'medium',
      status: 'pending',
      subtasks: data.subtasks || [],
      category: data.category || 'General',
      difficulty: data.difficulty || 'medium',
      urgencyScore: calculateStaticUrgency(
        data.deadline || new Date(Date.now() + 86400000).toISOString(),
        data.priority || 'medium',
        data.difficulty || 'medium'
      ),
      createdAt: new Date().toISOString()
    };

    setTasks(prev => [t, ...prev]);
    setSelectedTask(t);
    setRecRefreshTrigger(prev => prev + 1);
  };

  const calculateStaticUrgency = (deadline: string, priority: string, difficulty: string): number => {
    const hoursLeft = (new Date(deadline).getTime() - Date.now()) / (1000 * 60 * 60);
    let base = 50;
    if (hoursLeft < 2) base = 95;
    else if (hoursLeft < 6) base = 85;
    else if (hoursLeft < 12) base = 75;
    else if (hoursLeft < 24) base = 65;
    else if (hoursLeft < 48) base = 50;
    else base = 30;

    if (priority === 'high') base += 10;
    if (priority === 'low') base -= 15;
    if (difficulty === 'hard') base += 5;

    return Math.max(1, Math.min(100, base));
  };

  const handleDeleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
    if (selectedTask?.id === id) {
      setSelectedTask(null);
    }
    setRecRefreshTrigger(prev => prev + 1);
  };

  const handleUpdateTask = (id: string, updatedFields: Partial<Task>) => {
    setTasks(prev => prev.map(t => {
      if (t.id === id) {
        const merged = { ...t, ...updatedFields };
        merged.urgencyScore = calculateStaticUrgency(
          merged.deadline,
          merged.priority,
          merged.difficulty
        );
        return merged;
      }
      return t;
    }));
    setSelectedTask(prev => {
      if (prev?.id === id) {
        const merged = { ...prev, ...updatedFields };
        merged.urgencyScore = calculateStaticUrgency(
          merged.deadline,
          merged.priority,
          merged.difficulty
        );
        return merged;
      }
      return prev;
    });
    setRecRefreshTrigger(prev => prev + 1);
  };

  // --- Subtask Editing & AI Decomposing State ---
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('');
  const [editingSubtaskId, setEditingSubtaskId] = useState<string | null>(null);
  const [editingSubtaskTitle, setEditingSubtaskTitle] = useState('');
  const [isDecomposing, setIsDecomposing] = useState(false);

  const handleAutoDecomposeSubtasks = async (task: Task) => {
    setIsDecomposing(true);
    try {
      const res = await fetch('/api/gemini/breakdown', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: task.title,
          description: task.description
        })
      });
      if (!res.ok) throw new Error('Breakdown API failed');
      const data = await res.json();
      if (data.subtasks && Array.isArray(data.subtasks)) {
        setTasks(prev => prev.map(t => {
          if (t.id === task.id) {
            return {
              ...t,
              subtasks: data.subtasks
            };
          }
          return t;
        }));
        if (selectedTask?.id === task.id) {
          setSelectedTask(prev => prev ? { ...prev, subtasks: data.subtasks } : null);
        }
      }
    } catch (e) {
      console.log("Decomposition error:", e);
    } finally {
      setIsDecomposing(false);
    }
  };

  const handleAddSubtask = (taskId: string, directTitle?: string) => {
    const titleToUse = directTitle || newSubtaskTitle;
    if (!titleToUse.trim()) return;
    const newSt: SubTask = {
      id: Math.random().toString(36).substring(2, 9),
      title: titleToUse.trim(),
      completed: false
    };

    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          subtasks: [...(t.subtasks || []), newSt]
        };
      }
      return t;
    }));

    if (selectedTask?.id === taskId) {
      setSelectedTask(prev => {
        if (!prev) return null;
        return {
          ...prev,
          subtasks: [...(prev.subtasks || []), newSt]
        };
      });
    }

    if (!directTitle) {
      setNewSubtaskTitle('');
    }
  };

  const handleEditSubtaskSave = (taskId: string, subtaskId: string) => {
    if (!editingSubtaskTitle.trim()) return;
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          subtasks: (t.subtasks || []).map(st => st.id === subtaskId ? { ...st, title: editingSubtaskTitle.trim() } : st)
        };
      }
      return t;
    }));

    if (selectedTask?.id === taskId) {
      setSelectedTask(prev => {
        if (!prev) return null;
        return {
          ...prev,
          subtasks: (prev.subtasks || []).map(st => st.id === subtaskId ? { ...st, title: editingSubtaskTitle.trim() } : st)
        };
      });
    }

    setEditingSubtaskId(null);
  };

  const handleDeleteSubtask = (taskId: string, subtaskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        return {
          ...t,
          subtasks: (t.subtasks || []).filter(st => st.id !== subtaskId)
        };
      }
      return t;
    }));

    if (selectedTask?.id === taskId) {
      setSelectedTask(prev => {
        if (!prev) return null;
        return {
          ...prev,
          subtasks: (prev.subtasks || []).filter(st => st.id !== subtaskId)
        };
      });
    }
  };

  const handleToggleSubtask = (taskId: string, subtaskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        const updatedSubtasks = t.subtasks.map(st => {
          if (st.id === subtaskId) {
            return { ...st, completed: !st.completed };
          }
          return st;
        });
        return { ...t, subtasks: updatedSubtasks };
      }
      return t;
    }));

    // Auto-update matched selected task references
    if (selectedTask?.id === taskId) {
      setSelectedTask(prev => {
        if (!prev) return null;
        return {
          ...prev,
          subtasks: prev.subtasks.map(st => st.id === subtaskId ? { ...st, completed: !st.completed } : st)
        };
      });
    }
  };

  const handleToggleTaskStatus = (taskId: string) => {
    let completedDifficulty: 'easy' | 'medium' | 'hard' = 'medium';
    let wasMarkedComplete = false;

    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        const nextStatus = t.status === 'completed' ? 'pending' : 'completed';
        wasMarkedComplete = (nextStatus === 'completed');
        completedDifficulty = t.difficulty || 'medium';
        return { ...t, status: nextStatus };
      }
      return t;
    }));

    if (wasMarkedComplete) {
      // update userBehavior productivity patterns
      setUserBehavior((prev: any) => {
        const minutes = completedDifficulty === 'easy' ? 15 : completedDifficulty === 'medium' ? 30 : 60;
        const currentHour = new Date().getHours();
        
        return {
          ...prev,
          productivityPatterns: {
            ...prev.productivityPatterns,
            completedTasksCount: (prev.productivityPatterns.completedTasksCount || 0) + 1,
            totalFocusMinutes: (prev.productivityPatterns.totalFocusMinutes || 0) + minutes,
            peakFocusHour: currentHour
          }
        };
      });
    }

    if (selectedTask?.id === taskId) {
      setSelectedTask(prev => {
        if (!prev) return null;
        return { ...prev, status: prev.status === 'completed' ? 'pending' : 'completed' };
      });
    }
    setRecRefreshTrigger(prev => prev + 1);
  };

  const handlePostponeTask = (taskId: string) => {
    setTasks(prev => prev.map(t => {
      if (t.id === taskId) {
        const oldDeadline = new Date(t.deadline);
        oldDeadline.setHours(oldDeadline.getHours() + 1); // Postpone 1 hour
        const newDeadlineStr = oldDeadline.toISOString().substring(0, 16);
        const newPostponedCount = (t.postponedCount || 0) + 1;

        // update user behavior
        setUserBehavior((prevBeh: any) => {
          const freq = [...(prevBeh.frequentlyPostponedTasks || [])];
          if (!freq.includes(t.title)) {
            freq.push(t.title);
          }
          return {
            ...prevBeh,
            frequentlyPostponedTasks: freq
          };
        });

        const updatedTask = {
          ...t,
          deadline: newDeadlineStr,
          postponedCount: newPostponedCount
        };

        // If an AI Survival Plan already exists, dynamically regenerate it!
        if (t.aiPlan) {
          setTimeout(() => {
            handleGenerateSurvivalPlan(updatedTask);
          }, 400);
        }

        return updatedTask;
      }
      return t;
    }));

    if (selectedTask?.id === taskId) {
      setSelectedTask(prev => {
        if (!prev) return null;
        const oldDeadline = new Date(prev.deadline);
        oldDeadline.setHours(oldDeadline.getHours() + 1);
        return {
          ...prev,
          deadline: oldDeadline.toISOString().substring(0, 16),
          postponedCount: (prev.postponedCount || 0) + 1
        };
      });
    }
    setPostponingTaskId(taskId);
    setRecRefreshTrigger(prev => prev + 1);
  };

  // --- AI Prioritization Engine Trigger ---
  const handleIntelligentPrioritize = async () => {
    setIsPrioritizing(true);
    try {
      const res = await fetch('/api/gemini/prioritize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tasks,
          currentLocalTime: new Date().toISOString()
        })
      });

      if (!res.ok) throw new Error('API prioritize failed');
      const data = await res.json();
      
      if (data.prioritizedTasks && Array.isArray(data.prioritizedTasks)) {
        setTasks(prev => {
          const updated = prev.map(t => {
            const scoreObj = data.prioritizedTasks.find((pt: any) => pt.id === t.id);
            if (scoreObj) {
              return { ...t, urgencyScore: scoreObj.urgencyScore };
            }
            return t;
          });
          // Sort descending by calculated dynamic urgency score
          return updated.sort((a, b) => b.urgencyScore - a.urgencyScore);
        });
      }
    } catch (err) {
      console.error(err);
      // Fallback local rule-based sorting
      setTasks(prev => {
        const withCalculated = prev.map(t => ({
          ...t,
          urgencyScore: calculateStaticUrgency(t.deadline, t.priority, t.difficulty)
        }));
        return withCalculated.sort((a, b) => b.urgencyScore - a.urgencyScore);
      });
    } finally {
      setIsPrioritizing(false);
      setRecRefreshTrigger(prev => prev + 1);
    }
  };

  // --- AI Survival Plan Generation Trigger ---
  const handleGenerateSurvivalPlan = async (task: Task) => {
    setIsPlanning(true);
    try {
      const res = await fetch('/api/gemini/survival-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: task.title,
          description: task.description,
          deadline: task.deadline,
          category: task.category,
          difficulty: task.difficulty,
          currentLocalTime: new Date().toISOString()
        })
      });

      if (!res.ok) throw new Error('Failed to fetch survival plan');
      const data = await res.json();

      setTasks(prev => prev.map(t => {
        if (t.id === task.id) {
          return { ...t, aiPlan: data };
        }
        return t;
      }));

      const updatedTask = { ...task, aiPlan: data };
      setSelectedTask(updatedTask);
      
      // Initialize step timer to first step
      if (data.steps && data.steps.length > 0) {
        setCurrentStepIndex(0);
        setTimeLeft(data.steps[0].duration * 60);
      }
    } catch (err) {
      console.error(err);
      // Fallback local high-intensity survival plan
      const fallbackPlan = {
        steps: [
          { id: 'fb-1', title: 'Deep Concentration Clean Setup', duration: 5, description: 'Close all communication channels. Close all browsers tabs. Put phone physically in another room.' },
          { id: 'fb-2', title: 'Intense Core Draft Block', duration: 25, description: 'Directly jump to writing and designing the core elements without editing. Focus purely on progress.' },
          { id: 'fb-3', title: 'Refine & Polish Run', duration: 15, description: 'Do a fast proof-read, adjust key margins, verify requirements, and lock down delivery.' }
        ],
        focusTips: [
          'Unplug dual monitor or set fullscreen mode to avoid multitasking.',
          'Open white noise or instrumental synth playlists to lock in focus.'
        ],
        estimatedTotalTime: 45,
        procrastinationBuster: "Procrastination is just fear of failure. Start now, write poorly, edit later. Go!"
      };

      setTasks(prev => prev.map(t => {
        if (t.id === task.id) {
          return { ...t, aiPlan: fallbackPlan };
        }
        return t;
      }));
      setSelectedTask({ ...task, aiPlan: fallbackPlan });
      setCurrentStepIndex(0);
      setTimeLeft(fallbackPlan.steps[0].duration * 60);
    } finally {
      setIsPlanning(false);
      setRecRefreshTrigger(prev => prev + 1);
    }
  };

  // --- Habits Operations ---
  const handleToggleHabit = (id: string) => {
    const todayStr = new Date().toISOString().split('T')[0];
    setHabits(prev => prev.map(h => {
      if (h.id === id) {
        const completedToday = h.lastCompleted === todayStr;
        let newStreak = h.streak;
        
        if (!completedToday) {
          newStreak += 1;
        } else {
          newStreak = Math.max(0, newStreak - 1);
        }

        return {
          ...h,
          streak: newStreak,
          lastCompleted: completedToday ? undefined : todayStr,
          history: {
            ...h.history,
            [todayStr]: !completedToday
          }
        };
      }
      return h;
    }));
    setRecRefreshTrigger(prev => prev + 1);
  };

  const handleCreateHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newHabitTitle.trim()) return;

    const newHabit: Habit = {
      id: `habit-${Date.now()}`,
      title: newHabitTitle,
      frequency: 'daily',
      streak: 0,
      history: {},
      createdAt: new Date().toISOString()
    };

    setHabits(prev => [...prev, newHabit]);
    setNewHabitTitle('');
    setRecRefreshTrigger(prev => prev + 1);
  };

  // --- Goals Operations ---
  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalTitle.trim()) return;

    const newGoal: Goal = {
      id: `goal-${Date.now()}`,
      title: newGoalTitle,
      targetDate: newGoalDate || new Date(Date.now() + 86400000 * 7).toISOString().split('T')[0],
      completed: false,
      category: newGoalCategory,
      tasksCount: 0,
      completedTasksCount: 0
    };

    setGoals(prev => [...prev, newGoal]);
    setNewGoalTitle('');
    setNewGoalDate('');
    setRecRefreshTrigger(prev => prev + 1);
  };

  const handleToggleGoal = (id: string) => {
    setGoals(prev => prev.map(g => {
      if (g.id === id) {
        return { ...g, completed: !g.completed };
      }
      return g;
    }));
    setRecRefreshTrigger(prev => prev + 1);
  };

  // --- Calendar Events Operations ---
  const handleCreateEvent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEventTitle.trim() || !newEventStart) return;

    const newEv: CalendarEvent = {
      id: `event-${Date.now()}`,
      title: newEventTitle,
      startTime: newEventStart,
      endTime: newEventEnd || newEventStart,
      associatedTaskId: newEventTaskId || undefined,
      color: 'violet'
    };

    setEvents(prev => [...prev, newEv]);
    setNewEventTitle('');
    setNewEventStart('');
    setNewEventEnd('');
    setNewEventTaskId('');
  };

  // AI Dynamic Scheduling slot booking helper
  const handleAutoScheduleTask = (task: Task) => {
    const today = new Date();
    // Schedule in next open hour block starting from 2 hours from now
    const startTime = new Date(today);
    startTime.setHours(startTime.getHours() + 2, 0, 0, 0);
    const endTime = new Date(startTime);
    endTime.setHours(endTime.getHours() + 1);

    const newEv: CalendarEvent = {
      id: `event-${Date.now()}`,
      title: `Survival Slot: ${task.title}`,
      startTime: startTime.toISOString().substring(0, 16),
      endTime: endTime.toISOString().substring(0, 16),
      associatedTaskId: task.id,
      color: 'rose'
    };

    setEvents(prev => [...prev, newEv]);
    setActiveTab('calendar');
  };

  // --- Voice Coach Proposal Actions Applicator ---
  const handleExecuteCoachProposal = (actionType: string, payload: any) => {
    if (actionType === 'create_task') {
      handleCreateTask({
        title: payload.title,
        deadline: payload.deadline,
        priority: payload.priority,
        category: payload.category,
        difficulty: payload.difficulty,
        description: 'Auto-proposed by AI Companion'
      });
    } else if (actionType === 'create_plan') {
      const target = tasks.find(t => t.id === payload.taskId) || tasks[0];
      if (target) {
        setSelectedTask(target);
        handleGenerateSurvivalPlan(target);
      }
    } else if (actionType === 'prioritize') {
      handleIntelligentPrioritize();
    } else if (actionType === 'block_time') {
      const firstUrgent = tasks.find(t => t.status !== 'completed');
      if (firstUrgent) {
        handleAutoScheduleTask(firstUrgent);
      }
    }
  };

  // Format seconds to MM:SS
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans flex flex-col antialiased">
      {/* Header Bar */}
      <header className="sticky top-0 z-40 bg-white/85 backdrop-blur-md border-b border-slate-100 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-indigo-100">
            <Zap className="w-5 h-5 fill-rose-100" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tight bg-gradient-to-r from-rose-600 to-indigo-700 bg-clip-text text-transparent">
              The Last-Minute Life Saver
            </h1>
            <p className="text-xs text-slate-400 font-medium">Real-time AI Panic & Procrastination Interceptor</p>
          </div>
        </div>

        <div className="flex items-center gap-3 relative">
          {/* Smart Notifications Dropdown Trigger */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 hover:bg-slate-100 rounded-xl border border-slate-200 text-slate-600 transition flex items-center justify-center relative"
              title="Smart Notifications"
            >
              <Bell className="w-4 h-4 text-indigo-600" />
              {notifications.length > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white rounded-full font-bold text-[9px] flex items-center justify-center animate-pulse">
                  {notifications.length}
                </span>
              )}
            </button>

            {/* Smart Notifications Popover */}
            {showNotifications && (
              <div className="absolute right-0 mt-3.5 w-80 bg-white border border-slate-150 rounded-2xl shadow-xl z-50 p-4 space-y-3">
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <span className="font-bold text-xs text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                    <Bell className="w-3.5 h-3.5 text-indigo-500" />
                    Live AI Diagnostics
                  </span>
                  <button 
                    onClick={() => setShowNotifications(false)}
                    className="text-[10px] text-slate-400 hover:text-slate-600 font-bold"
                  >
                    CLOSE
                  </button>
                </div>

                <div className="space-y-2.5 max-h-[300px] overflow-y-auto">
                  {notifications.length === 0 ? (
                    <p className="text-xs text-slate-400 italic text-center py-4">No active warnings. System fully optimized!</p>
                  ) : (
                    notifications.map(n => (
                      <div 
                        key={n.id} 
                        className={`p-2.5 rounded-xl border text-[11px] leading-relaxed ${
                          n.type === 'warning' 
                            ? 'bg-amber-50/60 border-amber-100 text-amber-800' 
                            : n.type === 'success' 
                            ? 'bg-emerald-50/60 border-emerald-100 text-emerald-800' 
                            : n.type === 'alert'
                            ? 'bg-rose-50/60 border-rose-100 text-rose-800'
                            : 'bg-indigo-50/60 border-indigo-100 text-indigo-800'
                        }`}
                      >
                        <strong className="block font-bold mb-0.5 uppercase tracking-wide text-[9px]">{n.title}</strong>
                        {n.text}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Global Live Clock */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-slate-100/60 rounded-xl border border-slate-200/50 text-xs text-slate-600">
            <Clock className="w-3.5 h-3.5 text-indigo-500" />
            <span>UTC: {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        </div>
      </header>

      {/* Primary Workspace */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Navigation Rail / Sidebar */}
        <div className="lg:col-span-3 flex flex-row lg:flex-col gap-1 overflow-x-auto lg:overflow-visible pb-2 lg:pb-0">
          {[
            { id: 'dashboard', label: 'Action Dashboard', icon: Zap, badge: tasks.filter(t => t.status === 'pending').length },
            { id: 'calendar', label: 'Survival Calendar', icon: CalendarIcon, badge: events.length },
            { id: 'habits', label: 'Goal & Habit Loop', icon: Flame, badge: habits.filter(h => h.streak > 0).length },
            { id: 'coach', label: 'Panic AI Companion', icon: Sparkles, badge: null }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition shrink-0 w-full text-left ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 hover:bg-white hover:text-slate-900'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span className="flex-1">{tab.label}</span>
                {tab.badge !== null && (
                  <span className={`px-2 py-0.5 text-[10px] rounded-full font-bold ${
                    isActive ? 'bg-indigo-500 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}

          <div className="hidden lg:block mt-6 border-t border-slate-200 pt-6">
            <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-4 mb-3">Live Threat Summary</h3>
            <div className="bg-white rounded-xl p-3.5 border border-slate-100 space-y-3 shadow-sm">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Urgent Backlog</span>
                <span className="font-bold text-rose-600">{tasks.filter(t => t.priority === 'high' && t.status !== 'completed').length} Tasks</span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div
                  className="bg-rose-500 h-full transition-all"
                  style={{
                    width: `${Math.min(100, (tasks.filter(t => t.status === 'completed').length / (tasks.length || 1)) * 100)}%`
                  }}
                />
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500">Day Completion</span>
                <span className="font-bold text-slate-700">
                  {Math.round((tasks.filter(t => t.status === 'completed').length / (tasks.length || 1)) * 100)}%
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Workspace Panel */}
        <div className="lg:col-span-9 space-y-6">
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              {/* AI Behavioral Feedback Loop - Postpone survey */}
              {postponingTaskId && tasks.find(t => t.id === postponingTaskId) && (
                <div className="bg-gradient-to-r from-amber-50 to-indigo-50 border border-indigo-100 p-4 rounded-2xl shadow-sm space-y-3">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <Brain className="w-4 h-4 text-indigo-600 animate-pulse" />
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wide">AI Behavioral Feedback Loop</span>
                    </div>
                    <button 
                      onClick={() => setPostponingTaskId(null)} 
                      className="text-slate-400 hover:text-slate-600 text-xs font-bold"
                    >
                      SKIP
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">
                    You just postponed <strong>&ldquo;{tasks.find(t => t.id === postponingTaskId)?.title}&rdquo;</strong>. Help the AI learn your behavior patterns to personalize future recommendations and survival plans:
                  </p>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {[
                      "Fatigue / Low Energy",
                      "Multitasking Distraction",
                      "Task is too big / Complex",
                      "Underestimated required effort",
                      "Waiting on someone else"
                    ].map(reason => (
                      <button
                        key={reason}
                        onClick={() => {
                          setUserBehavior((prevBeh: any) => {
                            const prevReasons = prevBeh.commonDelayReasons || {};
                            const updatedReasons = {
                              ...prevReasons,
                              [reason]: (prevReasons[reason] || 0) + 1
                            };
                            return {
                              ...prevBeh,
                              commonDelayReasons: updatedReasons
                            };
                          });
                          setPostponingTaskId(null);
                        }}
                        className="px-3 py-1.5 bg-white hover:bg-indigo-600 border border-slate-200 hover:border-indigo-600 text-slate-600 hover:text-white rounded-xl text-xs font-medium transition shadow-sm"
                      >
                        {reason}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Backlog List & Focus Area Bento Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Panel 1: Urgent Backlog Control */}
                <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="font-semibold text-slate-800 text-base font-sans">Tactical Focus Board</h2>
                      <p className="text-[10px] text-slate-400">Streamlined directives to eliminate cognitive friction</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleIntelligentPrioritize}
                        disabled={isPrioritizing}
                        className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-lg text-xs font-semibold transition flex items-center gap-1"
                        title="Analyze and re-order tasks based on real deadline gravity"
                      >
                        <SlidersHorizontal className="w-3.5 h-3.5" />
                        {isPrioritizing ? 'Sorting...' : 'AI Prioritize'}
                      </button>

                      <button
                        onClick={() => setShowTaskForm(!showTaskForm)}
                        className="p-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Task Addition Form Drawer */}
                  {showTaskForm && (
                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!newTaskTitle.trim()) return;
                        handleCreateTask({
                          title: newTaskTitle,
                          description: newTaskDesc,
                          deadline: newTaskDeadline || new Date(Date.now() + 86400000).toISOString().substring(0, 16),
                          priority: newTaskPriority,
                          category: newTaskCategory,
                          difficulty: newTaskDifficulty,
                        });
                        setNewTaskTitle('');
                        setNewTaskDesc('');
                        setNewTaskDeadline('');
                        setShowTaskForm(false);
                      }}
                      className="bg-slate-50 border border-slate-100 rounded-xl p-4 mb-4 space-y-3"
                    >
                      <div>
                        <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Task Title</label>
                        <input
                          type="text"
                          required
                          value={newTaskTitle}
                          onChange={(e) => setNewTaskTitle(e.target.value)}
                          placeholder="e.g., File sales taxes before midnight"
                          className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs focus:outline-indigo-500"
                        />
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Context / Description</label>
                        <textarea
                          value={newTaskDesc}
                          onChange={(e) => setNewTaskDesc(e.target.value)}
                          placeholder="Add any specific context here..."
                          className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs focus:outline-indigo-500 h-16 resize-none"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Deadline Time</label>
                          <input
                            type="datetime-local"
                            required
                            value={newTaskDeadline}
                            onChange={(e) => setNewTaskDeadline(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Category</label>
                          <select
                            value={newTaskCategory}
                            onChange={(e) => setNewTaskCategory(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                          >
                            <option>Work</option>
                            <option>Personal</option>
                            <option>Education</option>
                            <option>General</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Priority</label>
                          <select
                            value={newTaskPriority}
                            onChange={(e) => setNewTaskPriority(e.target.value as any)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                          >
                            <option value="high">High Priority</option>
                            <option value="medium">Medium</option>
                            <option value="low">Low</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-[11px] font-bold text-slate-400 uppercase mb-1">Difficulty</label>
                          <select
                            value={newTaskDifficulty}
                            onChange={(e) => setNewTaskDifficulty(e.target.value as any)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                          >
                            <option value="easy">Easy Task</option>
                            <option value="medium">Medium Focus</option>
                            <option value="hard">Hard Work</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex gap-2 justify-end pt-2">
                        <button
                          type="button"
                          onClick={() => setShowTaskForm(false)}
                          className="px-3 py-1.5 bg-white text-slate-600 border border-slate-200 rounded-lg text-xs"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold"
                        >
                          Add Backlog Task
                        </button>
                      </div>
                    </form>
                  )}

                  {/* Tasks Container */}
                  <div className="flex-1 space-y-4 max-h-[500px] overflow-y-auto pr-1">
                    {tasks.length === 0 ? (
                      <div className="text-center py-10 text-slate-400 text-sm">
                        No active survival tasks. You are safe for now!
                      </div>
                    ) : (
                      <div className="space-y-4">
                        {/* 1. Primary Directives (Top 3) */}
                        <div className="space-y-2">
                          <div className="text-[10px] font-bold text-indigo-600 tracking-wider uppercase flex items-center gap-1.5 mb-1">
                            <Zap className="w-3.5 h-3.5 fill-indigo-100" />
                            Primary Directives (Top 3)
                          </div>

                          {(() => {
                            const pendingTasks = tasks.filter(t => t.status !== 'completed');
                            const sortedPending = [...pendingTasks].sort((a, b) => b.urgencyScore - a.urgencyScore);
                            const topThree = sortedPending.slice(0, 3);

                            if (topThree.length === 0) {
                              return <p className="text-xs text-slate-400 italic py-2 pl-2 border-l-2 border-slate-100">No active directives. Add a task or enjoy your peace!</p>;
                            }

                            return topThree.map((task) => {
                              const isSelected = selectedTask?.id === task.id;
                              const isOverdue = new Date(task.deadline).getTime() < Date.now();

                              return (
                                <div
                                  key={task.id}
                                  onClick={() => handleSelectTask(task)}
                                  className={`p-3.5 rounded-xl border text-left cursor-pointer transition relative overflow-hidden ${
                                    isSelected
                                      ? 'bg-indigo-50/60 border-indigo-200 shadow-sm ring-1 ring-indigo-200'
                                      : 'bg-slate-50/40 hover:bg-slate-50 border-slate-100/70 hover:border-slate-200'
                                  }`}
                                >
                                  {/* Threat urgency indicator bar */}
                                  <div
                                    className="absolute top-0 left-0 bottom-0 w-1"
                                    style={{
                                      backgroundColor: isOverdue 
                                        ? '#ef4444' 
                                        : task.urgencyScore > 85 
                                        ? '#f43f5e' 
                                        : task.urgencyScore > 60 
                                        ? '#f59e0b' 
                                        : '#10b981'
                                    }}
                                  />

                                  <div className="flex items-start justify-between gap-2 pl-2">
                                    <div className="flex-1">
                                      <h3 className="font-semibold text-slate-800 text-xs">
                                        {task.title}
                                      </h3>
                                      <p className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                                        <span className="font-bold text-indigo-500">{task.category}</span>
                                        <span>•</span>
                                        <span className={isOverdue ? 'text-rose-600 font-bold' : ''}>
                                          Due {new Date(task.deadline).toLocaleDateString([], { month: 'short', day: 'numeric' })} at {new Date(task.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                        </span>
                                      </p>
                                    </div>

                                    <div className="flex flex-col items-end shrink-0">
                                      <span className={`px-2 py-0.5 text-[8px] rounded-full font-bold uppercase tracking-wider ${
                                        task.urgencyScore > 85 
                                          ? 'bg-rose-100 text-rose-700' 
                                          : task.urgencyScore > 60 
                                          ? 'bg-amber-100 text-amber-700' 
                                          : 'bg-emerald-100 text-emerald-700'
                                      }`}>
                                        Urgency {task.urgencyScore}
                                      </span>
                                    </div>
                                  </div>

                                  {/* Inline quick control buttons to empower dynamic plans */}
                                  <div className="mt-3.5 pl-2 flex items-center justify-between border-t border-slate-100/60 pt-2.5">
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handlePostponeTask(task.id);
                                      }}
                                      className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 hover:text-amber-800 rounded-lg text-[9px] font-bold border border-transparent hover:border-amber-100 transition"
                                      title="Postpone by 1 hour & dynamically update survival coordinates"
                                    >
                                      Postpone +1h
                                    </button>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setSelectedTask(task);
                                        setIsEditingTask(true);
                                      }}
                                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[9px] font-bold transition flex items-center gap-1"
                                      title="Edit task details"
                                    >
                                      <Edit className="w-2.5 h-2.5" />
                                      Edit
                                    </button>
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleToggleTaskStatus(task.id);
                                      }}
                                      className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-[9px] font-bold transition"
                                    >
                                      Done
                                    </button>
                                  </div>
                                </div>
                              );
                            });
                          })()}
                        </div>

                        {/* 2. Secondary Objectives (Collapsible) */}
                        {(() => {
                          const pendingTasks = tasks.filter(t => t.status !== 'completed');
                          const sortedPending = [...pendingTasks].sort((a, b) => b.urgencyScore - a.urgencyScore);
                          const secondaryQueue = sortedPending.slice(3);

                          if (secondaryQueue.length === 0) return null;

                          return (
                            <div className="border-t border-slate-100/80 pt-3">
                              <button
                                type="button"
                                onClick={() => setShowSecondaryTasks(!showSecondaryTasks)}
                                className="w-full flex items-center justify-between text-[10px] font-bold text-slate-400 tracking-wider uppercase py-1.5 hover:text-slate-600 transition"
                              >
                                <span>Secondary Queue ({secondaryQueue.length})</span>
                                <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded text-[8px] font-bold">
                                  {showSecondaryTasks ? 'COLLAPSE' : 'EXPAND'}
                                </span>
                              </button>

                              {showSecondaryTasks && (
                                <div className="space-y-2 mt-2">
                                  {secondaryQueue.map((task) => {
                                    const isSelected = selectedTask?.id === task.id;
                                    return (
                                      <div
                                        key={task.id}
                                        onClick={() => handleSelectTask(task)}
                                        className={`p-3 rounded-xl border text-left cursor-pointer transition relative overflow-hidden ${
                                          isSelected
                                            ? 'bg-slate-50 border-slate-200'
                                            : 'bg-white hover:bg-slate-50/50 border-slate-100'
                                        }`}
                                      >
                                        <div className="flex items-center justify-between gap-2">
                                          <div>
                                            <h4 className="font-semibold text-slate-700 text-[11px]">{task.title}</h4>
                                            <p className="text-[9px] text-slate-400 mt-0.5">
                                              Due {new Date(task.deadline).toLocaleDateString([], { month: 'short', day: 'numeric' })} at {new Date(task.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                            </p>
                                          </div>
                                          <div className="flex items-center gap-1.5">
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                setSelectedTask(task);
                                                setIsEditingTask(true);
                                              }}
                                              className="px-1.5 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-[8px] font-bold transition flex items-center gap-0.5"
                                              title="Edit task details"
                                            >
                                              <Edit className="w-2 h-2" />
                                              Edit
                                            </button>
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handlePostponeTask(task.id);
                                              }}
                                              className="px-1.5 py-0.5 hover:bg-amber-50 text-amber-600 hover:text-amber-700 rounded text-[8px] font-bold border border-slate-100"
                                            >
                                              +1h
                                            </button>
                                            <button
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                handleToggleTaskStatus(task.id);
                                              }}
                                              className="px-1.5 py-0.5 bg-indigo-50 text-indigo-700 rounded text-[8px] font-bold"
                                            >
                                              Done
                                            </button>
                                          </div>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })()}

                        {/* 3. Completed Objectives (Collapsible) */}
                        {(() => {
                          const completedTasks = tasks.filter(t => t.status === 'completed');
                          if (completedTasks.length === 0) return null;

                          return (
                            <div className="border-t border-slate-100/80 pt-3">
                              <button
                                type="button"
                                onClick={() => setShowCompletedTasks(!showCompletedTasks)}
                                className="w-full flex items-center justify-between text-[10px] font-bold text-slate-400 tracking-wider uppercase py-1.5 hover:text-slate-600 transition"
                              >
                                <span>Completed Objectives ({completedTasks.length})</span>
                                <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded text-[8px] font-bold">
                                  {showCompletedTasks ? 'COLLAPSE' : 'EXPAND'}
                                </span>
                              </button>

                              {showCompletedTasks && (
                                <div className="space-y-2 mt-2">
                                  {completedTasks.map((task) => {
                                    const isSelected = selectedTask?.id === task.id;
                                    return (
                                      <div
                                        key={task.id}
                                        onClick={() => handleSelectTask(task)}
                                        className={`p-2.5 rounded-xl border text-left cursor-pointer transition ${
                                          isSelected
                                            ? 'bg-slate-50 border-slate-200 opacity-80'
                                            : 'bg-white border-slate-100 opacity-60'
                                        }`}
                                      >
                                        <div className="flex items-center justify-between gap-2">
                                          <div>
                                            <h4 className="font-medium text-slate-600 text-[11px] line-through">{task.title}</h4>
                                            <span className="text-[9px] text-emerald-600 font-semibold">Done</span>
                                          </div>
                                          <button
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handleToggleTaskStatus(task.id);
                                            }}
                                            className="px-1.5 py-0.5 bg-slate-100 text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 rounded text-[9px] font-medium transition"
                                          >
                                            Undo
                                          </button>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        })()}
                      </div>
                    )}
                  </div>
                </div>

                {/* Panel 2: Live Tactical Survival Plan Focus Area */}
                <div id="task-focus-anchor" className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 flex flex-col relative">
                  {selectedTask ? (
                    isEditingTask ? (
                      <form
                        onSubmit={(e) => {
                          e.preventDefault();
                          handleUpdateTask(selectedTask.id, {
                            title: editTaskTitle,
                            description: editTaskDesc,
                            deadline: editTaskDeadline,
                            priority: editTaskPriority,
                            category: editTaskCategory,
                            difficulty: editTaskDifficulty,
                          });
                          setIsEditingTask(false);
                        }}
                        className="space-y-4"
                      >
                        <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                          <h3 className="font-semibold text-slate-800 text-sm flex items-center gap-1.5 font-sans">
                            <Edit className="w-4 h-4 text-indigo-600" />
                            Edit Task Details
                          </h3>
                          <button
                            type="button"
                            onClick={() => setIsEditingTask(false)}
                            className="text-xs text-slate-400 hover:text-slate-600 font-semibold"
                          >
                            Cancel
                          </button>
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Task Title</label>
                          <input
                            type="text"
                            required
                            value={editTaskTitle}
                            onChange={(e) => setEditTaskTitle(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs focus:outline-indigo-500 font-semibold text-slate-800"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Date & Time (Deadline)</label>
                          <input
                            type="datetime-local"
                            required
                            value={editTaskDeadline}
                            onChange={(e) => setEditTaskDeadline(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 focus:outline-indigo-500"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Description / Context</label>
                          <textarea
                            value={editTaskDesc}
                            onChange={(e) => setEditTaskDesc(e.target.value)}
                            className="w-full bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs focus:outline-indigo-500 h-20 resize-none leading-relaxed text-slate-600"
                          />
                        </div>

                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Category</label>
                            <select
                              value={editTaskCategory}
                              onChange={(e) => setEditTaskCategory(e.target.value)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                            >
                              <option>Work</option>
                              <option>Personal</option>
                              <option>Education</option>
                              <option>General</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Priority</label>
                            <select
                              value={editTaskPriority}
                              onChange={(e) => setEditTaskPriority(e.target.value as any)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                            >
                              <option value="high">High</option>
                              <option value="medium">Medium</option>
                              <option value="low">Low</option>
                            </select>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Difficulty</label>
                            <select
                              value={editTaskDifficulty}
                              onChange={(e) => setEditTaskDifficulty(e.target.value as any)}
                              className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                            >
                              <option value="easy">Easy</option>
                              <option value="medium">Medium</option>
                              <option value="hard">Hard</option>
                            </select>
                          </div>
                        </div>

                        <div className="flex gap-2 justify-end pt-2 border-t border-slate-100">
                          <button
                            type="button"
                            onClick={() => setIsEditingTask(false)}
                            className="px-3 py-1.5 bg-slate-50 text-slate-600 border border-slate-200 rounded-lg text-xs hover:bg-slate-100 transition"
                          >
                            Cancel
                          </button>
                          <button
                            type="submit"
                            className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-sm transition"
                          >
                            Save Changes
                          </button>
                        </div>
                      </form>
                    ) : (
                      <div className="space-y-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] text-slate-600 font-semibold uppercase">
                                {selectedTask.category}
                              </span>
                              <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] text-slate-600 font-semibold uppercase">
                                {selectedTask.difficulty}
                              </span>
                              {selectedTask.priority === 'high' && (
                                <span className="px-2 py-0.5 bg-rose-100 rounded text-[10px] text-rose-700 font-bold uppercase">
                                  High Priority
                                </span>
                              )}
                            </div>
                            <h2 className="font-semibold text-slate-800 text-lg leading-tight">{selectedTask.title}</h2>
                            <p className="text-[10px] text-slate-400 mt-1">
                              Due: {new Date(selectedTask.deadline).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })} at {new Date(selectedTask.deadline).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            <button
                              onClick={() => {
                                setIsEditingTask(true);
                                setEditTaskTitle(selectedTask.title);
                                setEditTaskDesc(selectedTask.description || '');
                                setEditTaskDeadline(selectedTask.deadline);
                                setEditTaskPriority(selectedTask.priority);
                                setEditTaskCategory(selectedTask.category);
                                setEditTaskDifficulty(selectedTask.difficulty);
                              }}
                              className="p-1.5 hover:bg-indigo-50 text-slate-400 hover:text-indigo-600 rounded-lg transition"
                              title="Edit task details"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteTask(selectedTask.id)}
                              className="p-1.5 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded-lg transition"
                              title="Delete task"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>

                      <p className="text-xs text-slate-500 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-100/50">
                        {selectedTask.description || "No context guidelines provided yet. Use the Voice AI Companion to construct high-value plans."}
                      </p>

                      {/* Voice Companion Panel */}
                      <div className="bg-slate-50/50 border border-slate-200/80 rounded-xl p-3.5 space-y-3">
                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <span className="relative flex h-2 w-2">
                              {isListeningForCommands && (
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-violet-400 opacity-75"></span>
                              )}
                              <span className={`relative inline-flex rounded-full h-2 w-2 ${isListeningForCommands ? 'bg-violet-600' : 'bg-slate-400'}`}></span>
                            </span>
                            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                              <Brain className="w-3.5 h-3.5 text-violet-500" />
                              Voice Guide & Assistant
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-1.5">
                            {/* Toggle Auto Voice Briefing */}
                            <button
                              onClick={() => {
                                const next = !voiceBriefingEnabled;
                                setVoiceBriefingEnabled(next);
                                if (!next) window.speechSynthesis.cancel();
                              }}
                              className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 transition ${
                                voiceBriefingEnabled
                                  ? 'bg-violet-50 text-violet-600 border-violet-200'
                                  : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-50'
                              }`}
                              title={voiceBriefingEnabled ? "Mute automatic selection briefing" : "Enable automatic selection briefing"}
                            >
                              {voiceBriefingEnabled ? <Volume2 className="w-3.5 h-3.5 text-violet-600" /> : <VolumeX className="w-3.5 h-3.5" />}
                              <span>{voiceBriefingEnabled ? 'Briefing On' : 'Briefing Off'}</span>
                            </button>

                            {/* Speak Now Button */}
                            <button
                              onClick={() => speakTaskDetails(selectedTask)}
                              className="p-1.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-800 rounded-lg text-[10px] font-bold flex items-center gap-1 transition"
                              title="Speak task details aloud"
                            >
                              <Volume2 className="w-3.5 h-3.5" />
                              <span>Speak</span>
                            </button>

                            {/* Listen Voice Command Button */}
                            <button
                              onClick={() => {
                                if (isListeningForCommands) {
                                  recognitionRef.current?.stop();
                                } else {
                                  try {
                                    recognitionRef.current?.start();
                                  } catch (err) {
                                    console.log('Start listening error:', err);
                                  }
                                }
                              }}
                              className={`p-1.5 rounded-lg border text-[10px] font-bold flex items-center gap-1 transition ${
                                isListeningForCommands
                                  ? 'bg-rose-50 text-rose-600 border-rose-200 animate-pulse'
                                  : 'bg-white text-slate-500 border-slate-200 hover:bg-slate-50'
                              }`}
                              title={isListeningForCommands ? "Stop listening for commands" : "Listen for voice commands"}
                            >
                              {isListeningForCommands ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                              <span>{isListeningForCommands ? 'Listening...' : 'Voice Command'}</span>
                            </button>
                          </div>
                        </div>

                        {/* Status feedback block */}
                        {voiceCommandFeedback && (
                          <div className={`p-2 rounded-lg text-[11px] font-medium leading-relaxed flex items-center gap-2 ${
                            voiceCommandFeedback.includes('Error') 
                              ? 'bg-rose-50 text-rose-600 border border-rose-100'
                              : voiceCommandFeedback.includes('Captured')
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                              : 'bg-violet-50 text-violet-700 border border-violet-100/60'
                          }`}>
                            <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
                            <span>{voiceCommandFeedback}</span>
                          </div>
                        )}

                        {/* Speech-to-text live help sheet */}
                        <div className="text-[10px] text-slate-400 leading-normal border-t border-slate-100 pt-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                          <div>
                            <span className="font-semibold text-slate-500 block">🔊 Audio Guidance:</span>
                            Reads details automatically when clicking/selecting any task.
                          </div>
                          <div>
                            <span className="font-semibold text-slate-500 block">🗣️ Say commands like:</span>
                            <code className="text-violet-600 font-mono">"tell me about it"</code>, <code className="text-violet-600 font-mono">"break task"</code>, <code className="text-violet-600 font-mono">"complete task"</code>, <code className="text-violet-600 font-mono">"add subtask [step]"</code>.
                          </div>
                        </div>
                      </div>

                      {/* AI Survival Plan Module */}
                      {selectedTask.aiPlan ? (
                        <div className="space-y-4 border-t border-slate-100 pt-4">
                          <div className="bg-indigo-900 text-indigo-50 rounded-2xl p-4 shadow-sm relative overflow-hidden">
                            {/* Ambient background accent */}
                            <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500 rounded-full blur-2xl opacity-40 -mr-6 -mt-6" />

                            <div className="flex items-center gap-1.5 text-xs text-indigo-300 font-bold uppercase tracking-wider mb-2">
                              <Sparkles className="w-4 h-4 fill-indigo-500 text-indigo-300 animate-pulse" />
                              Survival Countdown Tracker
                            </div>

                            <div className="grid grid-cols-2 gap-4 relative z-10">
                              <div>
                                <span className="text-[10px] uppercase tracking-wider text-indigo-300 block">Active Step</span>
                                <span className="font-semibold text-sm line-clamp-1">
                                  {selectedTask.aiPlan.steps[currentStepIndex]?.title || 'Get Started'}
                                </span>
                              </div>
                              <div className="text-right">
                                <span className="text-[10px] uppercase tracking-wider text-indigo-300 block">Step Time Left</span>
                                <span className="font-mono font-bold text-xl block tracking-tight text-indigo-100">
                                  {formatTime(timeLeft)}
                                </span>
                              </div>
                            </div>

                            <div className="mt-3 flex gap-2 relative z-10">
                              <button
                                onClick={toggleTimer}
                                className="flex-1 py-1.5 bg-indigo-500 hover:bg-indigo-400 text-white rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition"
                              >
                                <Play className="w-3.5 h-3.5 fill-white" />
                                {timerRunning ? 'Pause step' : 'Start countdown'}
                              </button>
                              <button
                                onClick={() => selectSurvivalStep(currentStepIndex)}
                                className="px-2.5 py-1.5 bg-indigo-800 hover:bg-indigo-700 text-indigo-200 rounded-lg text-xs"
                                title="Reset timer"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>

                          {/* Steps Roadmap */}
                          <div className="space-y-2">
                            <div className="text-xs font-bold text-slate-400 tracking-wider uppercase mb-1 flex justify-between">
                              <span>Action Steps</span>
                              <span>Total: {selectedTask.aiPlan.estimatedTotalTime} mins</span>
                            </div>
                            <div className="space-y-2 max-h-[180px] overflow-y-auto pr-1">
                              {selectedTask.aiPlan.steps.map((step, i) => {
                                const isCurrent = currentStepIndex === i;
                                return (
                                  <div
                                    key={step.id}
                                    onClick={() => selectSurvivalStep(i)}
                                    className={`p-2.5 rounded-xl border text-xs text-left cursor-pointer transition flex items-center gap-2.5 ${
                                      isCurrent
                                        ? 'bg-indigo-50/50 border-indigo-200 text-slate-800'
                                        : 'bg-white hover:bg-slate-50 border-slate-100 text-slate-600'
                                    }`}
                                  >
                                    <div className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-[10px] shrink-0 ${
                                      isCurrent ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-400'
                                    }`}>
                                      {i + 1}
                                    </div>
                                    <div className="flex-1">
                                      <p className="font-semibold line-clamp-1">{step.title}</p>
                                      <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">{step.description}</p>
                                    </div>
                                    <span className="text-[10px] font-bold text-slate-400 shrink-0">{step.duration}m</span>
                                  </div>
                                );
                              })}
                            </div>
                          </div>

                          {/* Focus Tips & Procrastination Buster */}
                          {selectedTask.aiPlan.procrastinationBuster && (
                            <div className="bg-rose-50 border border-rose-100 rounded-xl p-3 text-xs text-rose-800 italic leading-snug">
                              <span className="font-bold uppercase not-italic tracking-wider text-[9px] block text-rose-600 mb-1">
                                🔥 Procrastination Buster challenge
                              </span>
                              {selectedTask.aiPlan.procrastinationBuster}
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="py-6 border-t border-slate-100 flex flex-col items-center justify-center text-center gap-4">
                          <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center text-indigo-500">
                            <Sparkles className="w-6 h-6 animate-pulse" />
                          </div>
                          <div>
                            <h4 className="font-semibold text-slate-800 text-sm">Need a structured plan?</h4>
                            <p className="text-xs text-slate-400 max-w-xs mt-1">
                              Let our AI decompose this objective into manageable, minute-by-minute survival blocks.
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleGenerateSurvivalPlan(selectedTask)}
                              disabled={isPlanning}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shadow-sm flex items-center gap-2 transition"
                            >
                              {isPlanning ? (
                                <>
                                  <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                                  Constructing plan...
                                </>
                              ) : (
                                <>
                                  <Sparkles className="w-3.5 h-3.5 fill-indigo-200" />
                                  Decompose with Gemini AI
                                </>
                              )}
                            </button>

                            <button
                              onClick={() => handleAutoScheduleTask(selectedTask)}
                              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition"
                            >
                              Auto-Schedule onto Calendar
                            </button>
                          </div>
                        </div>
                      )}

                      {/* Future Impact Simulator */}
                      <div className="border-t border-slate-100 pt-4 space-y-2">
                        <button
                          onClick={() => setShowImpactSimulator(!showImpactSimulator)}
                          className="flex items-center justify-between w-full text-xs font-bold text-slate-700 uppercase tracking-wide py-1.5 px-2.5 rounded-lg bg-slate-50 hover:bg-slate-100 transition"
                        >
                          <div className="flex items-center gap-1.5">
                            <Activity className="w-3.5 h-3.5 text-indigo-500" />
                            <span>🔮 AI Future Impact Simulator</span>
                          </div>
                          <span className="text-[10px] text-indigo-600">
                            {showImpactSimulator ? 'Hide Impact Analysis' : 'Show Impact Analysis (+1h delay)'}
                          </span>
                        </button>

                        <AnimatePresence>
                          {showImpactSimulator && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              exit={{ opacity: 0, height: 0 }}
                              transition={{ duration: 0.15 }}
                              className="space-y-3 overflow-hidden pt-1"
                            >
                              <p className="text-[10px] text-slate-400 leading-normal">
                                Instantly compare metrics of executing this task immediately versus delaying it.
                              </p>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                                {/* Complete Now Card */}
                                <div className="bg-emerald-50/40 border border-emerald-100/60 rounded-xl p-3 space-y-2.5">
                                  <span className="text-[9px] font-bold text-emerald-800 uppercase bg-emerald-100 px-2 py-0.5 rounded-full inline-block">
                                    Option A: Complete Now
                                  </span>
                                  <div className="space-y-1.5 text-xs text-slate-600">
                                    <div className="flex justify-between items-center pb-1 border-b border-emerald-100/20">
                                      <span className="text-slate-500 text-[10px]">Expected Finish:</span>
                                      <strong className="text-emerald-700 font-bold text-[11px]">Soon (Next 35m)</strong>
                                    </div>
                                    <div className="flex justify-between items-center pb-1 border-b border-emerald-100/20">
                                      <span className="text-slate-500 text-[10px]">Workload Pile:</span>
                                      <strong className="text-emerald-700 font-bold text-[11px]">-45% Score</strong>
                                    </div>
                                    <div className="flex justify-between items-center pb-1 border-b border-emerald-100/20">
                                      <span className="text-slate-500 text-[10px]">Burnout Risk:</span>
                                      <strong className="text-emerald-700 font-bold text-[11px]">Minimal (15%)</strong>
                                    </div>
                                    <div className="flex justify-between items-center pb-1 border-b border-emerald-100/20">
                                      <span className="text-slate-500 text-[10px]">Goal Progress:</span>
                                      <strong className="text-emerald-700 font-bold text-[11px]">+12% speed</strong>
                                    </div>
                                  </div>
                                </div>

                                {/* Postpone Card */}
                                <div className="bg-rose-50/40 border border-rose-100/60 rounded-xl p-3 space-y-2.5">
                                  <span className="text-[9px] font-bold text-rose-800 uppercase bg-rose-100 px-2 py-0.5 rounded-full inline-block">
                                    Option B: Postpone (+1h)
                                  </span>
                                  <div className="space-y-1.5 text-xs text-slate-600">
                                    <div className="flex justify-between items-center pb-1 border-b border-rose-100/20">
                                      <span className="text-slate-500 text-[10px]">Expected Finish:</span>
                                      <strong className="text-rose-700 font-bold text-[11px]">Late (11:30 PM)</strong>
                                    </div>
                                    <div className="flex justify-between items-center pb-1 border-b border-rose-100/20">
                                      <span className="text-slate-500 text-[10px]">Workload Pile:</span>
                                      <strong className="text-rose-700 font-bold text-[11px]">+35% Pile</strong>
                                    </div>
                                    <div className="flex justify-between items-center pb-1 border-b border-rose-100/20">
                                      <span className="text-slate-500 text-[10px]">Burnout Risk:</span>
                                      <strong className="text-rose-700 font-bold text-[11px]">Severe (80%)</strong>
                                    </div>
                                    <div className="flex justify-between items-center pb-1 border-b border-rose-100/20">
                                      <span className="text-slate-500 text-[10px]">Goal Progress:</span>
                                      <strong className="text-rose-700 font-bold text-[11px]">Stagnant</strong>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>

                      {/* Subtask Checklists */}
                      <div className="border-t border-slate-100 pt-4 space-y-3">
                        <div className="flex justify-between items-center">
                          <div className="text-xs font-bold text-slate-400 tracking-wider uppercase">Granular Subtasks Checklist</div>
                          <span className="text-[10px] font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                            {selectedTask.subtasks.filter(s => s.completed).length}/{selectedTask.subtasks.length} Completed
                          </span>
                        </div>

                        {/* AI Decomposer Banner recommendation if task is hard/long or has no subtasks */}
                        {(selectedTask.difficulty === 'hard' || selectedTask.subtasks.length === 0) && (
                          <div className="bg-indigo-50/60 border border-indigo-100 p-3 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                            <div className="flex items-center gap-2">
                              <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse shrink-0" />
                              <span className="text-slate-700 font-medium">Decompose this complex task into realistic steps with AI?</span>
                            </div>
                            <button
                              onClick={() => handleAutoDecomposeSubtasks(selectedTask)}
                              disabled={isDecomposing}
                              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-semibold rounded-lg transition shrink-0"
                            >
                              {isDecomposing ? "Analyzing..." : "✨ Auto-Decompose"}
                            </button>
                          </div>
                        )}

                        {/* Subtasks checklist items */}
                        {selectedTask.subtasks.length === 0 ? (
                          <div className="text-xs text-slate-400 italic py-1">No granular subtasks declared yet. Add steps manually below or use the AI Decomposer.</div>
                        ) : (
                          <div className="space-y-1.5">
                            {selectedTask.subtasks.map((st) => {
                              const isEditing = editingSubtaskId === st.id;
                              return (
                                <div key={st.id} className="flex items-center justify-between gap-2 p-2 hover:bg-slate-50 border border-transparent hover:border-slate-100 rounded-lg group transition text-xs">
                                  {isEditing ? (
                                    <div className="flex-1 flex gap-2">
                                      <input
                                        type="text"
                                        value={editingSubtaskTitle}
                                        onChange={(e) => setEditingSubtaskTitle(e.target.value)}
                                        className="flex-1 px-2 py-0.5 border border-slate-200 rounded text-xs"
                                        onKeyDown={(e) => {
                                          if (e.key === 'Enter') handleEditSubtaskSave(selectedTask.id, st.id);
                                        }}
                                        autoFocus
                                      />
                                      <button
                                        onClick={() => handleEditSubtaskSave(selectedTask.id, st.id)}
                                        className="px-2 py-0.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded text-[10px] font-bold"
                                      >
                                        Save
                                      </button>
                                      <button
                                        onClick={() => setEditingSubtaskId(null)}
                                        className="px-2 py-0.5 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded text-[10px]"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : (
                                    <>
                                      <button
                                        onClick={() => handleToggleSubtask(selectedTask.id, st.id)}
                                        className="flex-1 flex items-center gap-2 text-left"
                                      >
                                        {st.completed ? (
                                          <CheckCircle className="w-4 h-4 text-indigo-600 shrink-0" />
                                        ) : (
                                          <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                                        )}
                                        <span className={st.completed ? 'line-through text-slate-400' : 'text-slate-700 font-medium'}>
                                          {st.title}
                                        </span>
                                      </button>
                                      <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1.5 transition">
                                        <button
                                          onClick={() => {
                                            setEditingSubtaskId(st.id);
                                            setEditingSubtaskTitle(st.title);
                                          }}
                                          className="text-[10px] text-slate-400 hover:text-indigo-600 font-bold px-1 py-0.5 rounded transition"
                                          title="Edit step"
                                        >
                                          Edit
                                        </button>
                                        <button
                                          onClick={() => handleDeleteSubtask(selectedTask.id, st.id)}
                                          className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition"
                                          title="Delete step"
                                        >
                                          <Trash2 className="w-3 h-3" />
                                        </button>
                                      </div>
                                    </>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        )}

                        {/* Add manual step input */}
                        <div className="flex gap-2 pt-1">
                          <input
                            type="text"
                            placeholder="Add manual step checklist item..."
                            value={newSubtaskTitle}
                            onChange={(e) => setNewSubtaskTitle(e.target.value)}
                            className="flex-1 px-3 py-1.5 border border-slate-200 focus:border-indigo-500 rounded-lg text-xs outline-none transition"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleAddSubtask(selectedTask.id);
                            }}
                          />
                          <button
                            onClick={() => handleAddSubtask(selectedTask.id)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 transition flex items-center justify-center shrink-0"
                            title="Add subtask step"
                          >
                            <Plus className="w-4 h-4 text-slate-500" />
                          </button>
                        </div>
                      </div>

                      {/* Quick Actions */}
                      <div className="flex gap-2 border-t border-slate-100 pt-4">
                        <button
                          onClick={() => handleToggleTaskStatus(selectedTask.id)}
                          className={`flex-1 py-2 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition ${
                            selectedTask.status === 'completed'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                          }`}
                        >
                          <Check className="w-4 h-4" />
                          {selectedTask.status === 'completed' ? 'Mark Pending' : 'Mark Task Completed'}
                        </button>
                      </div>
                    </div>
                  )
                ) : (
                    <div className="py-24 text-center text-slate-400 text-sm space-y-2">
                      <Zap className="w-8 h-8 mx-auto text-slate-300 animate-bounce" />
                      <p>Select or create a backlog task to activate focus guidelines.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Proactive smart advisor card */}
              <RecommendationCard
                tasks={tasks}
                habits={habits}
                goals={goals}
                userBehavior={userBehavior}
                onFocusTaskSelect={(t) => {
                  handleSelectTask(t);
                  // scroll to active task focus area
                  document.getElementById('task-focus-anchor')?.scrollIntoView({ behavior: 'smooth' });
                }}
                onGeneratePlan={(t) => {
                  handleSelectTask(t);
                  handleGenerateSurvivalPlan(t);
                }}
                refreshTrigger={recRefreshTrigger}
              />
            </div>
          )}

          {activeTab === 'calendar' && (
            <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="font-semibold text-slate-800 text-base">Survival Calendar</h2>
                  <p className="text-xs text-slate-400">Lock down dedicated study & concentration blocks</p>
                </div>

                <div className="text-xs text-indigo-600 font-semibold bg-indigo-50 px-3 py-1.5 rounded-lg flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5" />
                  Visual Hourly Map
                </div>
              </div>

              {/* Add Custom Calendar Block Form */}
              <form onSubmit={handleCreateEvent} className="bg-slate-50 border border-slate-100 rounded-xl p-4 grid grid-cols-1 md:grid-cols-4 gap-3 items-end">
                <div className="md:col-span-1">
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Block Title</label>
                  <input
                    type="text"
                    required
                    value={newEventTitle}
                    onChange={(e) => setNewEventTitle(e.target.value)}
                    placeholder="e.g., Deep Focus Block"
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Start Time</label>
                  <input
                    type="datetime-local"
                    required
                    value={newEventStart}
                    onChange={(e) => setNewEventStart(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 focus:outline-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">End Time</label>
                  <input
                    type="datetime-local"
                    required
                    value={newEventEnd}
                    onChange={(e) => setNewEventEnd(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-600 focus:outline-indigo-500"
                  />
                </div>
                <div>
                  <button
                    type="submit"
                    className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Reserve Block
                  </button>
                </div>
              </form>

              {/* Time Blocks Visualizer */}
              <div className="space-y-3">
                <div className="text-xs font-bold text-slate-400 tracking-wider uppercase">Your Scheduled Focus Slots</div>
                {events.length === 0 ? (
                  <div className="py-12 text-center text-slate-400 text-sm">No scheduled concentration slots. Go to Action Dashboard to allocate slots.</div>
                ) : (
                  <div className="space-y-2">
                    {events.map((ev) => {
                      const matchedTask = tasks.find(t => t.id === ev.associatedTaskId);
                      return (
                        <div
                          key={ev.id}
                          className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-100 rounded-xl hover:border-slate-200 transition"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-3 h-3 rounded-full bg-violet-500 shrink-0" />
                            <div>
                              <h4 className="font-semibold text-slate-800 text-xs">{ev.title}</h4>
                              <p className="text-[10px] text-slate-400 mt-0.5">
                                {new Date(ev.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(ev.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-2">
                            {matchedTask && (
                              <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded text-[9px] font-bold">
                                Task Linked
                              </span>
                            )}
                            <button
                              onClick={() => setEvents(prev => prev.filter(e => e.id !== ev.id))}
                              className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'habits' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Habits Container */}
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-6">
                <div>
                  <h2 className="font-semibold text-slate-800 text-base">Habit Loop Tracker</h2>
                  <p className="text-xs text-slate-400">Keep streaks active to avoid long-term decay</p>
                </div>

                <form onSubmit={handleCreateHabit} className="flex gap-2">
                  <input
                    type="text"
                    required
                    value={newHabitTitle}
                    onChange={(e) => setNewHabitTitle(e.target.value)}
                    placeholder="Create a daily habit (e.g., Code 30m)"
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs focus:outline-indigo-500"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold transition"
                  >
                    Add
                  </button>
                </form>

                <div className="space-y-2">
                  {habits.map((h) => {
                    const completedToday = h.lastCompleted === new Date().toISOString().split('T')[0];
                    return (
                      <div
                        key={h.id}
                        className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between"
                      >
                        <div>
                          <h4 className="font-semibold text-slate-800 text-xs">{h.title}</h4>
                          <div className="flex items-center gap-1 text-[10px] text-slate-400 mt-1">
                            <Flame className={`w-3.5 h-3.5 ${h.streak > 0 ? 'text-amber-500 fill-amber-500' : ''}`} />
                            <span>Streak: {h.streak} days</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleToggleHabit(h.id)}
                            className={`px-3 py-1 rounded-lg text-[10px] font-bold transition ${
                              completedToday
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                : 'bg-indigo-600 text-white hover:bg-indigo-700'
                            }`}
                          >
                            {completedToday ? 'Completed' : 'Complete'}
                          </button>
                          <button
                            onClick={() => setHabits(prev => prev.filter(ha => ha.id !== h.id))}
                            className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Milestones / Goals Container */}
              <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-6">
                <div>
                  <h2 className="font-semibold text-slate-800 text-base">Core Target Goals</h2>
                  <p className="text-xs text-slate-400">Anchor your last-minute efforts on big milestones</p>
                </div>

                <form onSubmit={handleCreateGoal} className="bg-slate-50 border border-slate-100 rounded-xl p-3.5 space-y-3">
                  <div>
                    <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Goal / Project Title</label>
                    <input
                      type="text"
                      required
                      value={newGoalTitle}
                      onChange={(e) => setNewGoalTitle(e.target.value)}
                      placeholder="e.g., Deliver complete final project"
                      className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs focus:outline-indigo-500"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Target Date</label>
                      <input
                        type="date"
                        required
                        value={newGoalDate}
                        onChange={(e) => setNewGoalDate(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Category</label>
                      <select
                        value={newGoalCategory}
                        onChange={(e) => setNewGoalCategory(e.target.value)}
                        className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-xs text-slate-600 focus:outline-indigo-500"
                      >
                        <option>Work</option>
                        <option>Education</option>
                        <option>Personal</option>
                      </select>
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="w-full py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold transition"
                  >
                    Anchor New Milestone Goal
                  </button>
                </form>

                <div className="space-y-2">
                  {goals.map((g) => (
                    <div
                      key={g.id}
                      className="p-3 bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-between"
                    >
                      <div className="flex items-start gap-2.5">
                        <button onClick={() => handleToggleGoal(g.id)} className="mt-0.5">
                          {g.completed ? (
                            <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-300 shrink-0" />
                          )}
                        </button>
                        <div>
                          <h4 className={`font-semibold text-slate-800 text-xs ${g.completed ? 'line-through opacity-50' : ''}`}>{g.title}</h4>
                          <span className="text-[10px] text-indigo-600 font-bold bg-indigo-50 px-1.5 py-0.5 rounded mt-1 inline-block">
                            Due {new Date(g.targetDate).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => setGoals(prev => prev.filter(go => go.id !== g.id))}
                        className="p-1 hover:bg-rose-50 text-slate-400 hover:text-rose-600 rounded transition"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'coach' && (
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
              {/* Left Column: Interactive Chat */}
              <div className="md:col-span-8">
                <CompanionChat
                  tasks={tasks}
                  habits={habits}
                  goals={goals}
                  userBehavior={userBehavior}
                  onExecuteSuggestedAction={handleExecuteCoachProposal}
                  triggerOpenWithTask={chatTriggerTask}
                />
              </div>

              {/* Right Column: Dynamic micro-tips sidebar */}
              <div className="md:col-span-4 bg-white rounded-2xl border border-slate-100 shadow-sm p-6 space-y-4">
                <div>
                  <h3 className="font-semibold text-slate-800 text-sm">Suggested Prompts</h3>
                  <p className="text-[10px] text-slate-400">Click a prompt to instantly task your coach</p>
                </div>

                <div className="space-y-2">
                  {[
                    "I have to submit my homework in 3 hours",
                    "Analyze my current task lists for crisis zones",
                    "Add an urgent high-priority meeting for tomorrow at 10 AM",
                    "Design a dynamic calendar slot to clean my desk"
                  ].map((p, i) => (
                    <button
                      key={i}
                      onClick={() => setChatTriggerTask(p)}
                      className="w-full p-2.5 text-left text-xs bg-slate-50 hover:bg-slate-100 border border-slate-100 hover:border-slate-200 rounded-xl transition text-slate-600 flex items-center gap-1"
                    >
                      <ChevronRight className="w-3.5 h-3.5 shrink-0 text-slate-400" />
                      <span className="line-clamp-2">{p}</span>
                    </button>
                  ))}
                </div>

                <div className="border-t border-slate-100 pt-4 space-y-2">
                  <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Voice Capture Mode</div>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Simply tap the **Mic** icon in the chat controls. Speak freely into your device microphone and say your immediate task (e.g. *&quot;Create high-priority assignment by 10 PM tonight&quot;*).
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Dynamic Status / Threat Footer Panel */}
      <footer className="mt-auto bg-white border-t border-slate-100 py-4 px-6">
        <div className="max-w-7xl mx-auto w-full flex flex-col md:flex-row justify-between items-center gap-2 text-xs text-slate-400">
          <div className="flex items-center gap-1.5">
            <ShieldAlert className="w-4 h-4 text-indigo-500" />
            <span>AI Guard Status: Live protecting the user from missing critical milestones.</span>
          </div>
          <div>
            <span>Press **Voice On** button inside Panic Coach tab to trigger text-to-speech.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
