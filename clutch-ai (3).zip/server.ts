import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini API securely using the environment key
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// Helper to double check key
const hasApiKey = () => !!process.env.GEMINI_API_KEY;

// ==========================================
// HIGH-FIDELITY LOCAL FALLBACK GENERATORS
// ==========================================

function generateFallbackSurvivalPlan(title: string, description: string, category: string, difficulty: string) {
  const steps = [];
  const estTotal = difficulty === 'hard' ? 90 : difficulty === 'medium' ? 45 : 20;
  
  if (difficulty === 'hard') {
    steps.push({
      id: "step-1",
      title: "Tactical Setup & Zero-Distraction Quarantine",
      duration: 15,
      description: `Silence all devices, activate Do Not Disturb, and open your working space for "${title}". Clear everything else from your desk.`
    });
    steps.push({
      id: "step-2",
      title: "Deconstruct & Structure Core Objectives",
      duration: 20,
      description: "Draft a high-level list of 3-4 structural components required to complete this task. Focus only on the skeleton."
    });
    steps.push({
      id: "step-3",
      title: "Deep Intensity Execution Block",
      duration: 40,
      description: "Set a timer and execute with zero editing or second-guessing. Write, build, or compile the core body of work without pausing."
    });
    steps.push({
      id: "step-4",
      title: "Refinement, Validation & Quality Assurance",
      duration: 15,
      description: `Proofread, test, and polish the final outputs for "${title}". Ensure all requirements are fully met.`
    });
  } else if (difficulty === 'medium') {
    steps.push({
      id: "step-1",
      title: "Frictionless Kickoff & Clear Space",
      duration: 10,
      description: `Open the file or workstation for "${title}". Tell yourself you are only going to work on this for 10 minutes to bypass resistance.`
    });
    steps.push({
      id: "step-2",
      title: "Core Heavy Lifting",
      duration: 25,
      description: "Focus on creating the bulk of the content or solving the primary hurdle. Do not look at notifications or other tabs."
    });
    steps.push({
      id: "step-3",
      title: "Polish & Final Submission Review",
      duration: 10,
      description: "Review your work for consistency, correct any small bugs or formatting errors, and mark the task as complete."
    });
  } else {
    steps.push({
      id: "step-1",
      title: "Instant 5-Minute Sprint Setup",
      duration: 5,
      description: `Open "${title}" immediately. Remove any steps that involve planning and dive straight into inputting data.`
    });
    steps.push({
      id: "step-2",
      title: "Rapid Execution & Finalization",
      duration: 15,
      description: "Knock out the simple checklist items. Work with speed over perfect aesthetics to secure immediate completion."
    });
  }

  return {
    steps,
    focusTips: [
      "Use the 20-20-20 rule to protect your cognitive energy: every 20 minutes look away to avoid fatigue.",
      "The hardest part is the first 2 minutes. Focus purely on taking one small action to build instant momentum."
    ],
    estimatedTotalTime: estTotal,
    procrastinationBuster: `🚀 Do 5 deep breaths, close all unneeded browser tabs right now, and let's conquer "${title}" before the deadline!`
  };
}

function generateFallbackRecommendations(tasks: any[] = [], habits: any[] = [], goals: any[] = [], userBehavior: any = {}) {
  const pendingTasks = tasks.filter(t => t.status !== 'completed');
  
  // Calculate dynamic urgency scores for sorting
  const scoredTasks = pendingTasks.map(t => {
    let score = t.urgencyScore;
    if (score === undefined || score === null) {
      const hoursRemaining = t.deadline ? (new Date(t.deadline).getTime() - Date.now()) / (1000 * 60 * 60) : 24;
      if (hoursRemaining <= 0) score = 100;
      else if (hoursRemaining <= 2) score = 95;
      else if (hoursRemaining <= 6) score = 85;
      else if (hoursRemaining <= 12) score = 75;
      else if (hoursRemaining <= 24) score = 60;
      else score = 35;
      
      if (t.priority === 'high') score += 10;
      if (t.priority === 'low') score -= 10;
      score = Math.max(10, Math.min(100, score));
    }
    return { ...t, computedUrgency: score };
  });

  const sortedTasks = [...scoredTasks].sort((a, b) => b.computedUrgency - a.computedUrgency);
  const primaryTask = sortedTasks[0];

  const totalEstTime = pendingTasks.reduce((sum, t) => sum + (t.estimatedDuration || (t.difficulty === 'hard' ? 90 : t.difficulty === 'medium' ? 45 : 20)), 0);
  const totalEstHours = Math.max(1, Math.round(totalEstTime / 60));

  let focusTask = {
    taskId: primaryTask ? primaryTask.id : null,
    reason: primaryTask 
      ? `This task is due soon and is currently your top priority! Let's get this done first to keep things stress-free.`
      : "Awesome! You have no homework or urgent chores to worry about. Use this free time to relax or form a fun habit!",
    delayConsequence: primaryTask 
      ? `If you wait, you'll have less time later, which can cause last-minute stress and study pressure.` 
      : "Everything is clear. Keep up the good work!",
    estimatedTime: primaryTask ? (primaryTask.estimatedDuration || (primaryTask.difficulty === 'hard' ? 90 : primaryTask.difficulty === 'medium' ? 45 : 20)) : 30,
    bestTimeToStart: primaryTask 
      ? new Date(Math.max(Date.now() + 10 * 60 * 1000)).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
      : "Now",
    confidenceScore: 95,
    decisionTimeline: [
      "Looked at your school and personal deadlines",
      "Calculated how long the task will take",
      "Picked the best starting time so you don't feel rushed",
      "Cleared out other distractions to help you focus"
    ]
  };

  const warnings = [];
  const overdueCount = pendingTasks.filter(t => new Date(t.deadline).getTime() < Date.now()).length;
  if (overdueCount > 0) {
    warnings.push({
      type: "critical_overdue",
      message: `You have ${overdueCount} past-due task${overdueCount > 1 ? 's' : ''} on your list!`,
      action: "Change the date or mark it done to get a fresh start."
    });
  }

  const uncompletedHabits = habits.filter(h => h.lastCompleted !== new Date().toISOString().split('T')[0]);
  if (uncompletedHabits.length > 0) {
    warnings.push({
      type: "habit_risk",
      message: `You haven't completed your "${uncompletedHabits[0].title}" habit yet!`,
      action: "Take just 2 minutes to do this habit and keep your streak alive."
    });
  }

  if (pendingTasks.length > 5) {
    warnings.push({
      type: "overloaded",
      message: `You have ${pendingTasks.length} active tasks on your board. Try focusing on just one thing right now!`,
      action: "Pick your top priority task and let the rest wait."
    });
  }

  if (warnings.length === 0) {
    warnings.push({
      type: "all_clear",
      message: "No urgent deadlines or forgotten habits. Looking good!",
      action: "Enjoy the peaceful moment or work on a goal."
    });
  }

  const focusLevelVal = habits.length > 0 
    ? Math.min(100, Math.round((habits.filter(h => h.lastCompleted === new Date().toISOString().split('T')[0]).length / habits.length) * 100)) 
    : 70;
  
  const consistencyScoreVal = habits.length > 0 
    ? Math.min(100, Math.round((habits.reduce((sum, h) => sum + (h.streak || 0), 0) / habits.length) * 15) + 40) 
    : 80;

  const stressVal = primaryTask 
    ? Math.min(100, Math.round(primaryTask.computedUrgency * 0.8 + overdueCount * 15)) 
    : 15;

  const burnoutRiskVal = Math.min(100, Math.round((pendingTasks.length * 8) + (totalEstTime / 12) + (stressVal * 0.3)));

  return {
    focusTask,
    warnings,
    advice: primaryTask 
      ? `Try to work on "${primaryTask.title}" right now. Close other tabs, silence your phone for 20 minutes, and just take a small first step.`
      : "You're in a great spot! Celebrate being ahead of your tasks, do a quick habit, and take a well-deserved break.",
    proactiveQuote: primaryTask 
      ? `"Doing it now makes it much easier." Take one tiny step right now to get going!`
      : `"The secret to getting ahead is getting started." Let's keep the good vibes rolling!`,
    dailyBriefing: {
      summary: pendingTasks.length > 0 
        ? `You have ${pendingTasks.length} tasks to look at today. It should take around ${totalEstHours} hour${totalEstHours > 1 ? 's' : ''} of focus to finish everything.`
        : "Awesome! You have absolutely zero pending tasks. Enjoy your day!",
      totalWorkHours: totalEstHours,
      habitsAtRisk: uncompletedHabits.map(h => h.title),
      recommendedFirstStep: primaryTask 
        ? `Spend just 5 minutes getting started on "${primaryTask.title}".` 
        : "Do a quick habit to keep your momentum high."
    },
    productivityHealth: {
      burnoutRisk: burnoutRiskVal,
      focusLevel: focusLevelVal,
      workloadScore: Math.min(100, pendingTasks.length * 15),
      consistencyScore: consistencyScoreVal,
      stressIndicator: stressVal,
      explanation: overdueCount > 0 
        ? "Some tasks are past their dates, which can make you feel a bit stressed. Let's adjust their time or finish them!"
        : burnoutRiskVal > 75 
        ? "Your workload is a bit heavy right now. Try to take regular study breaks so you don't burn out."
        : "Your study health is awesome! You have a great balance of habits and tasks right now."
    }
  };
}

function generateFallbackChat(message: string, tasks: any[] = [], habits: any[] = [], goals: any[] = [], userBehavior: any = {}) {
  const msg = message.toLowerCase();
  let reply = "I'm right here in your corner. Let's block out the noise, find the biggest bottleneck in your list, and attack it step-by-step. What should we tackle?";
  let suggestedAction: any = null;

  if (msg.includes("add") || msg.includes("create") || msg.includes("remember") || msg.includes("schedule") || msg.includes("need to")) {
    let title = "New Tactical Task";
    const match = message.match(/(?:add|create|remember to|need to|schedule)\s+([^,?.!]+)/i);
    if (match && match[1]) {
      title = match[1].trim();
    }
    
    let deadline = new Date();
    if (msg.includes("tonight") || msg.includes("today")) {
      deadline.setHours(21, 0, 0, 0);
    } else if (msg.includes("tomorrow")) {
      deadline.setDate(deadline.getDate() + 1);
      deadline.setHours(12, 0, 0, 0);
    } else {
      deadline.setHours(deadline.getHours() + 3);
    }

    reply = `Consider it done! I've formulated a directive for "${title}" on your Tactical Focus Board. Let's make a real-time plan to knock this out.`;
    suggestedAction = {
      type: "create_task",
      payload: {
        title,
        deadline: deadline.toISOString().substring(0, 16),
        priority: msg.includes("urgent") || msg.includes("high") ? "high" : "medium",
        category: msg.includes("study") || msg.includes("school") ? "Education" : msg.includes("work") || msg.includes("job") ? "Work" : "Personal",
        difficulty: msg.includes("hard") || msg.includes("big") ? "hard" : "medium"
      }
    };
  } else if (msg.includes("plan") || msg.includes("survival") || msg.includes("how to")) {
    const pending = tasks.filter(t => t.status !== 'completed');
    if (pending.length > 0) {
      const matchTask = pending.find(t => msg.includes(t.title.toLowerCase())) || pending[0];
      reply = `Let's draw up an absolute direct, zero-excuses AI Survival Plan for "${matchTask.title}". Open it on your screen and let's lock in!`;
      suggestedAction = {
        type: "create_plan",
        payload: {
          taskId: matchTask.id,
          taskTitle: matchTask.title
        }
      };
    } else {
      reply = "You don't have any pending tasks right now! Let's set up a new priority target first, and then we'll map out a perfect micro-plan.";
    }
  } else if (msg.includes("prioritize") || msg.includes("sort") || msg.includes("organize")) {
    reply = "Let's run a full dynamic threat-level triage on all your current tasks to highlight your top 3 primary directives instantly.";
    suggestedAction = {
      type: "prioritize",
      payload: {}
    };
  } else if (msg.includes("overwhelmed") || msg.includes("stressed") || msg.includes("anxious")) {
    reply = "Deep breath in, hold for 3 seconds, and let it out. You are not your to-do list. Let's collapse everything except your absolute highest urgency item and focus only on the next 10 minutes. We can handle anything for 10 minutes.";
  } else if (msg.includes("lazy") || msg.includes("procrastinat") || msg.includes("stuck")) {
    reply = "Procrastination is just stress in disguise. Bypassing it is easy: pick your easiest task, set a 5-minute timer, and promise yourself you can stop when it rings. Let's do a micro-sprint right now!";
  }

  return { reply, suggestedAction };
}

function generateFallbackPrioritization(tasks: any[] = [], currentLocalTime: string) {
  const refTime = currentLocalTime ? new Date(currentLocalTime).getTime() : Date.now();
  
  const prioritizedTasks = tasks.map(t => {
    let score = 50;
    const hoursRemaining = t.deadline ? (new Date(t.deadline).getTime() - refTime) / (1000 * 60 * 60) : 24;
    
    if (hoursRemaining <= 0) {
      score = 98;
    } else if (hoursRemaining <= 2) {
      score = 95;
    } else if (hoursRemaining <= 6) {
      score = 85;
    } else if (hoursRemaining <= 12) {
      score = 75;
    } else if (hoursRemaining <= 24) {
      score = 62;
    } else if (hoursRemaining <= 48) {
      score = 45;
    } else {
      score = 25;
    }

    if (t.priority === 'high') score += 12;
    else if (t.priority === 'low') score -= 12;

    if (t.difficulty === 'hard') score += 8;
    else if (t.difficulty === 'easy') score -= 5;

    score = Math.max(10, Math.min(100, Math.round(score)));

    let reason = "Standard timeline baseline evaluation.";
    if (hoursRemaining <= 0) {
      reason = `Overdue by ${Math.abs(Math.round(hoursRemaining))} hours. Action required immediately to clear this bottleneck.`;
    } else if (hoursRemaining <= 2) {
      reason = `Critical threat window! Due in only ${Math.round(hoursRemaining * 60)} minutes. Stop everything else.`;
    } else if (hoursRemaining <= 6) {
      reason = `Due in ${Math.round(hoursRemaining)} hours. Starting this task protects you from a late-day workload wave.`;
    } else if (hoursRemaining <= 24) {
      reason = `Due in ${Math.round(hoursRemaining)} hours. High priority to execute during your peak focus state.`;
    } else if (t.priority === 'high') {
      reason = "Marked as high importance. Knocking this out early secures peace of mind.";
    } else {
      reason = "Lower threat index. Complete this after primary directives are closed.";
    }

    return {
      id: t.id,
      urgencyScore: score,
      reason
    };
  });

  return { prioritizedTasks };
}

// --- Gemini API Rate Limiting & Fallback State ---
let rateLimitExpiry = 0;

function checkRateLimit() {
  return Date.now() < rateLimitExpiry;
}

function handleRateLimitDetected() {
  // Grace period of 60 seconds before trying the live model again
  rateLimitExpiry = Date.now() + 60000;
}

// 1. Health & Configuration Check
app.get("/api/config", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: hasApiKey(),
  });
});

// 2. AISurvivalPlan Generator
// Creates a hyper-actionable, minute-by-minute breakdown for an urgent task
app.post("/api/gemini/survival-plan", async (req, res) => {
  const { title, description, deadline, category, difficulty, currentLocalTime } = req.body;

  if (!title) {
    return res.status(400).json({ error: "Task title is required." });
  }

  // Gracefully fall back to local engine if key is not configured or rate limited
  if (!hasApiKey() || checkRateLimit()) {
    return res.json(generateFallbackSurvivalPlan(title, description, category, difficulty));
  }

  const prompt = `
    Generate a high-intensity, hyper-realistic "survival plan" to complete the following task before its deadline.
    
    Task Details:
    - Title: "${title}"
    - Description: "${description || 'No description provided.'}"
    - Category: "${category || 'General'}"
    - Difficulty: "${difficulty || 'medium'}"
    - Deadline: "${deadline || 'No specific time'}"
    - Current local time: "${currentLocalTime || new Date().toISOString()}"
    
    The survival plan must break down this task into specific, sequential, actionable steps.
    Each step must have a Title, specific Duration in minutes (e.g., 15, 30, 45 minutes), and a micro-description of exactly what to do and how to avoid distraction.
    The total duration of all steps combined should be realistic for the difficulty and timeframe, but optimized to save last-minute panic.
    Provide 2-3 laser-focused, custom focus/prep tips.
    Also, generate a humorous yet highly motivating "procrastination buster" quote or challenge specifically for this task to force the user to start right now.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are 'The Survival Guide', an direct, highly encouraging, hyper-practical AI productivity companion. Your tone is urgent, supportive, zero-BS, and completely action-focused. You hate fluff; you love momentum.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["steps", "focusTips", "estimatedTotalTime", "procrastinationBuster"],
          properties: {
            estimatedTotalTime: {
              type: Type.INTEGER,
              description: "The total estimated time in minutes to complete all steps."
            },
            procrastinationBuster: {
              type: Type.STRING,
              description: "A funny, motivating, direct wake-up call or quick physical challenge to defeat resistance (e.g., 'Do 5 jumping jacks, close all tabs except this one, and set a timer for 15 minutes. GO!')"
            },
            focusTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "2-3 hyper-specific environment or mental focus tips (e.g., put phone in another room)."
            },
            steps: {
              type: Type.ARRAY,
              description: "The concrete steps to execute sequentially.",
              items: {
                type: Type.OBJECT,
                required: ["id", "title", "duration", "description"],
                properties: {
                  id: { type: Type.STRING },
                  title: { type: Type.STRING, description: "Action-oriented title of the step (e.g., 'Draft outline & core arguments')" },
                  duration: { type: Type.INTEGER, description: "Duration of this step in minutes" },
                  description: { type: Type.STRING, description: "Micro-instructions on what to do and what to ignore." }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    res.json(JSON.parse(text || "{}"));
  } catch (error: any) {
    const errString = String(error);
    if (errString.includes("429") || errString.includes("quota") || errString.includes("RESOURCE_EXHAUSTED")) {
      handleRateLimitDetected();
    }
    console.log("Survival plan request routed to local engine fallback.");
    res.json(generateFallbackSurvivalPlan(title, description, category, difficulty));
  }
});

// 3. Personalized Productivity Recommendations
// Evaluates the list of tasks, habits, and goals to flag procrastination traps and suggest the single best next action.
app.post("/api/gemini/recommendations", async (req, res) => {
  const { tasks, habits, goals, currentLocalTime, userBehavior } = req.body;

  // Gracefully fall back to local engine if key is not configured or rate limited
  if (!hasApiKey() || checkRateLimit()) {
    return res.json(generateFallbackRecommendations(tasks, habits, goals, userBehavior));
  }

  const prompt = `
    Analyze the user's current situation and give them simple, friendly, student-focused study advice.
    The user is a student, so keep language simple, encouraging, and free of complicated business or analytical jargon.
    
    Current Time: ${currentLocalTime || new Date().toISOString()}
    
    User State:
    - Tasks: ${JSON.stringify(tasks || [])}
    - Habits: ${JSON.stringify(habits || [])}
    - Goals: ${JSON.stringify(goals || [])}
    - Learned User Behavior / Patterns: ${JSON.stringify(userBehavior || { preferredWorkingHours: "Afternoon (12PM - 5PM)", averageCompletionTimeMinutes: 45 })}
    
    Tasks details might include priority, difficulty, deadline, and estimated duration.
    
    Please compute:
    1. The single absolute highest priority/most urgent task the user must focus on RIGHT NOW ("focusTask") to stay on track.
       For this focus task, compute:
       - Why it was selected (reason) - describe in a simple, friendly student-to-student way.
       - What happens if they delay it ("What Happens If I Don't?" analysis - delayConsequence) - make it clear and easy to understand (e.g. last-minute stress, late homework).
       - Estimated completion time in minutes (estimatedTime)
       - Best time to start today (bestTimeToStart, e.g. "2:00 PM")
       - Confidence score for this recommendation from 0 to 100 (confidenceScore)
       - AI Decision Timeline (decisionTimeline: 3-4 simple steps/reasoning points showing how you picked this, e.g., ["Checked your study deadlines", "Calculated how long the task will take", "Cleared other distractions for you"]).
    2. Specific warnings (e.g., overdue homework, habit streak about to break, goal target is tomorrow but progress is low, general task overload) in friendly language.
    3. Practical, supportive, and kind study advice.
    4. A witty, motivational quote to beat procrastination.
    5. A personalized Daily AI Briefing:
       - summary: A warm 1-2 sentence overview of their work today.
       - totalWorkHours: Total focus hours required for today's outstanding tasks.
       - habitsAtRisk: List of titles of habits that are in danger of being missed.
       - recommendedFirstStep: The very first small action they should do in the next 10 minutes to build momentum.
    6. AI-based Productivity Health indicators (0-100 values estimated using deadlines, workload, and completion history):
       - burnoutRisk: Higher if they have many high-urgency tasks or long estimated durations.
       - focusLevel: Higher if they completed subtasks recently or have active habit streaks.
       - workloadScore: Proportional to pending tasks and total complexity.
       - consistencyScore: Based on active habit streaks and goal progress.
       - stressIndicator: Based on overdue tasks, short deadlines, or impossible schedules.
       - explanation: A warm, clear summary of their overall study health.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the Student-Friendly Life Saver AI Study Coach. Your job is to analyze the student's task list, simplify their workload, and present stress, focus, and study recommendations in a very clear, easy-to-understand, supportive student tone. Avoid complicated technical terms, system coordinate jargon, or extreme metrics. Speak like a helpful study buddy.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["focusTask", "warnings", "advice", "proactiveQuote", "dailyBriefing", "productivityHealth"],
          properties: {
            focusTask: {
              type: Type.OBJECT,
              required: ["taskId", "reason", "delayConsequence", "estimatedTime", "bestTimeToStart", "confidenceScore", "decisionTimeline"],
              properties: {
                taskId: { type: Type.STRING, description: "The ID of the task they should work on. Leave null or empty string if no tasks exist." },
                reason: { type: Type.STRING, description: "Why this task is critical right now." },
                delayConsequence: { type: Type.STRING, description: "Predict concrete consequences of postponing or skipping this task (e.g., missed deadlines, increased workload piling up, broken milestones)." },
                estimatedTime: { type: Type.INTEGER, description: "Estimated completion time of this task in minutes." },
                bestTimeToStart: { type: Type.STRING, description: "Best time to start, e.g. '11:15 AM'." },
                confidenceScore: { type: Type.INTEGER, description: "Confidence score from 0 to 100." },
                decisionTimeline: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Reasoning factors (e.g. ['Analyzed deadline proximity', 'Evaluated task difficulty', 'Weighed morning productivity peak', 'Estimated high confidence index'])"
                }
              }
            },
            warnings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["type", "message", "action"],
                properties: {
                  type: { type: Type.STRING, description: "Type of warning (e.g., 'deadline_critical', 'habit_risk', 'overloaded', 'schedule_conflict')" },
                  message: { type: Type.STRING, description: "Clear, specific alert message." },
                  action: { type: Type.STRING, description: "Direct next action to address this warning." }
                }
              }
            },
            advice: { type: Type.STRING, description: "General personalized advice on how to organize their time or handle focus roadblocks." },
            proactiveQuote: { type: Type.STRING, description: "A punchy, witty line about beating procrastination." },
            dailyBriefing: {
              type: Type.OBJECT,
              required: ["summary", "totalWorkHours", "habitsAtRisk", "recommendedFirstStep"],
              properties: {
                summary: { type: Type.STRING, description: "A conversational 1-2 sentence overview of today's workload." },
                totalWorkHours: { type: Type.INTEGER, description: "Estimated total work hours to complete all pending tasks." },
                habitsAtRisk: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Habit titles that haven't been completed today." },
                recommendedFirstStep: { type: Type.STRING, description: "The best starting action to trigger momentum." }
              }
            },
            productivityHealth: {
              type: Type.OBJECT,
              required: ["burnoutRisk", "focusLevel", "workloadScore", "consistencyScore", "stressIndicator", "explanation"],
              properties: {
                burnoutRisk: { type: Type.INTEGER },
                focusLevel: { type: Type.INTEGER },
                workloadScore: { type: Type.INTEGER },
                consistencyScore: { type: Type.INTEGER },
                stressIndicator: { type: Type.INTEGER },
                explanation: { type: Type.STRING }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    res.json(JSON.parse(text || "{}"));
  } catch (error: any) {
    const errString = String(error);
    if (errString.includes("429") || errString.includes("quota") || errString.includes("RESOURCE_EXHAUSTED")) {
      handleRateLimitDetected();
    }
    console.log("Recommendations request routed to local engine fallback.");
    res.json(generateFallbackRecommendations(tasks, habits, goals, userBehavior));
  }
});

// 4. Voice & Chat Assistant
// Interactive text/voice companion. Users can talk to it, and it can suggest concrete app operations.
app.post("/api/gemini/chat", async (req, res) => {
  const { message, history, tasks, habits, goals, currentLocalTime, userBehavior } = req.body;

  // Gracefully fall back to local engine if key is not configured or rate limited
  if (!hasApiKey() || checkRateLimit()) {
    return res.json(generateFallbackChat(message, tasks, habits, goals, userBehavior));
  }

  const prompt = `
    User Message: "${message}"
    
    Current local time: "${currentLocalTime || new Date().toISOString()}"
    Current tasks: ${JSON.stringify(tasks || [])}
    Current habits: ${JSON.stringify(habits || [])}
    Current goals: ${JSON.stringify(goals || [])}
    User Behavior learned patterns: ${JSON.stringify(userBehavior || {})}
    
    Respond to the user with a brief, supportive, and direct response. Act as a proactive AI Productivity Coach.
    Provide actionable guidance, contextual encouragement, or alert them about imminent threats (e.g. "You have two assignments due in 3 hours, let's lock down!").
    
    Crucial Capability:
    If the user is asking to add a task, schedule something, make a plan for a task, or sort their list, you should identify this intent and propose a structured "suggestedAction" so the client can automatically create or update the data.
    
    Possible actions:
    1. 'create_task': when they want to add a task (e.g., 'I need to write an essay by 9pm tonight'). Extract title, priority ('high'|'medium'|'low'), deadline (ISO format or approximated datetime based on current time), category, and difficulty.
    2. 'create_plan': when they want to make a survival plan for a task that already exists, or for a new task they just named.
    3. 'prioritize': when they want to clean up or prioritize their day.
    4. 'block_time': when they want to map out free hours.
    
    Ensure the "reply" is warm, witty, supportive, and directly addresses their words with high coaching value.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the AI Productivity Coach of 'The Last-Minute Life Saver' application. Your role is to serve as an active coach. Always reply in concise, direct, spoken-friendly sentences. Guide users throughout their day, warning them when work piles up, helping them reschedule conflicts, and giving them quick physical/mental buster prompts. If the user wants to add a task or schedule something, include a 'suggestedAction' payload.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["reply"],
          properties: {
            reply: { type: Type.STRING, description: "The friendly, coaching-focused response (max 3 sentences)." },
            suggestedAction: {
              type: Type.OBJECT,
              required: ["type", "payload"],
              properties: {
                type: { type: Type.STRING, description: "The type of action: 'create_task', 'create_plan', 'prioritize', or 'block_time'" },
                payload: {
                  type: Type.OBJECT,
                  description: "Data fields for the action. For 'create_task', include keys: 'title', 'deadline' (ISO datetime, e.g., '2026-06-28T21:00'), 'priority' ('high'|'medium'|'low'), 'category', 'difficulty' ('easy'|'medium'|'hard'). For 'create_plan', include 'taskId' or 'taskTitle'."
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    res.json(JSON.parse(text || "{}"));
  } catch (error: any) {
    const errString = String(error);
    if (errString.includes("429") || errString.includes("quota") || errString.includes("RESOURCE_EXHAUSTED")) {
      handleRateLimitDetected();
    }
    console.log("Chat request routed to local engine fallback.");
    res.json(generateFallbackChat(message, tasks, habits, goals, userBehavior));
  }
});

// 5. Intelligent Task Prioritization
// Re-calculates urgency scores (0-100) dynamically using actual time, difficulty, and importance.
app.post("/api/gemini/prioritize", async (req, res) => {
  const { tasks, currentLocalTime } = req.body;

  if (!tasks || tasks.length === 0) {
    return res.json({ prioritizedTasks: [] });
  }

  // Gracefully fall back to local engine if key is not configured or rate limited
  if (!hasApiKey() || checkRateLimit()) {
    return res.json(generateFallbackPrioritization(tasks, currentLocalTime));
  }

  const prompt = `
    Analyze this list of tasks and evaluate their urgency.
    
    Current Time: ${currentLocalTime || new Date().toISOString()}
    
    Tasks:
    ${JSON.stringify(tasks)}
    
    For each task, compute a dynamic "urgencyScore" (0 to 100) based on:
    - How close the deadline is (tasks due in <2 hours are 95-100, tasks due today are 80-95, tasks due tomorrow 60-80, etc.).
    - Task difficulty and estimated effort.
    - Initial priority setting.
    
    Provide a dynamic computed urgencyScore and a 1-sentence action-focused reason why it is positioned there (e.g., 'Only 90 minutes left, and this medium task requires multi-step concentration.').
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the Prioritization Engine. Your job is to look past self-reported priority fields and calculate absolute ground-truth urgency scores based on deadline proximity and complexity. Return only the updated metadata list.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["prioritizedTasks"],
          properties: {
            prioritizedTasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["id", "urgencyScore", "reason"],
                properties: {
                  id: { type: Type.STRING },
                  urgencyScore: { type: Type.INTEGER, description: "A calculated score from 0 (relaxed) to 100 (panic crisis)." },
                  reason: { type: Type.STRING, description: "A brief, ultra-compelling 1-sentence reason for this score." }
                }
              }
            }
          }
        }
      }
    });

    const text = response.text;
    res.json(JSON.parse(text || "{}"));
  } catch (error: any) {
    const errString = String(error);
    if (errString.includes("429") || errString.includes("quota") || errString.includes("RESOURCE_EXHAUSTED")) {
      handleRateLimitDetected();
    }
    console.log("Prioritize request routed to local engine fallback.");
    res.json(generateFallbackPrioritization(tasks, currentLocalTime));
  }
});

// --- Smart Task Breakdown Fallback & Route ---
function generateFallbackBreakdown(title: string, description: string) {
  return {
    subtasks: [
      { id: Math.random().toString(36).substring(2, 9), title: `Draft architecture and dependencies for: ${title}`, completed: false, durationMinutes: 10 },
      { id: Math.random().toString(36).substring(2, 9), title: "Core execution and implementation phase", completed: false, durationMinutes: 25 },
      { id: Math.random().toString(36).substring(2, 9), title: "Verify edge cases, review and polish", completed: false, durationMinutes: 15 }
    ]
  };
}

app.post("/api/gemini/breakdown", async (req, res) => {
  const { title, description } = req.body;
  if (!title) {
    return res.status(400).json({ error: "Task title is required." });
  }

  if (!hasApiKey() || checkRateLimit()) {
    return res.json(generateFallbackBreakdown(title, description));
  }

  try {
    const prompt = `Given a task titled "${title}" with description "${description || 'None'}", decompose it into 3 to 5 realistic, sequential subtasks with approximate duration in minutes.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are an expert AI productivity strategist. Break down a complex, high-friction task into a neat set of actionable subtasks.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          required: ["subtasks"],
          properties: {
            subtasks: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                required: ["title", "durationMinutes"],
                properties: {
                  title: { type: Type.STRING },
                  durationMinutes: { type: Type.INTEGER }
                }
              }
            }
          }
        }
      }
    });

    const data = JSON.parse(response.text || "{}");
    const formattedSubtasks = (data.subtasks || []).map((st: any) => ({
      id: Math.random().toString(36).substring(2, 9),
      title: st.title,
      completed: false,
      durationMinutes: st.durationMinutes || 15
    }));

    res.json({ subtasks: formattedSubtasks });
  } catch (error) {
    const errString = String(error);
    if (errString.includes("429") || errString.includes("quota") || errString.includes("RESOURCE_EXHAUSTED")) {
      handleRateLimitDetected();
    }
    console.log("Breakdown request routed to local engine fallback.");
    res.json(generateFallbackBreakdown(title, description));
  }
});


// 6. Vite Dev / Prod static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
